(() => {
  // src/customization.ts
  var EXTENSION_CUSTOMIZATION = {
    whatsappWebOrigin: "https://web.whatsapp.com",
    api: {
      clientBaseDomain: "uazapi.com",
      authHeaderName: "token",
      paths: {
        instanceStatus: "/instance/status",
        importWebSessionStart: "/instance/import-web-session/start",
        importWebSessionChunk: "/instance/import-web-session/chunk",
        importWebSessionFinish: "/instance/import-web-session/finish",
        importWebSessionHistory: "/instance/import-web-session/history"
      }
    },
    importLimits: {
      chunkItems: 1e3,
      historyChatLimit: 5e3
    },
    importDefaults: {
      // History is useful for continuity, but it depends on WhatsApp Web cache.
      // The service worker imports the session first and treats history failures
      // as warnings so this default cannot break the credential migration.
      includeHistory: true
    },
    appBridge: {
      source: "whatsapp-session-transfer",
      matches: [
        "https://connect.sessiontransfer.com/*",
        "https://*.uazapi.com/*"
      ]
    },
    panelText: {
      title: "Migrar sess\xE3o",
      defaultStatus: "WhatsApp Web conectado",
      loggedOutStatus: "Entre no WhatsApp Web para importar",
      clientLabel: "Nome da assinatura",
      clientPlaceholder: "ex: minha-loja",
      tokenLabel: "Token",
      tokenPlaceholder: "token",
      importButton: "Migrar sess\xE3o",
      diagnoseButton: "Baixar diagn\xF3stico",
      dumpHistoryButton: "Baixar hist\xF3rico",
      historyOnlyButton: "Repassar hist\xF3rico",
      dumpSessionButton: "Baixar sess\xE3o",
      exitDevModeButton: "Sair do modo t\xE9cnico",
      modeDefault: "Modo padr\xE3o",
      modeTechnical: "Modo t\xE9cnico",
      showToken: "Mostrar token",
      hideToken: "Ocultar token",
      clearToken: "Apagar token",
      closePanel: "Fechar painel",
      openSettings: "Configura\xE7\xF5es",
      closeSettings: "Fechar configura\xE7\xF5es",
      settingsTitle: "Configura\xE7\xF5es",
      autoOpenSetting: "Abrir painel automaticamente",
      autoOpenSettingHint: "Mesmo desativado, chamadas pelo SDK/bridge continuam abrindo o painel.",
      themeSetting: "Tema do painel",
      themeFollowWhatsApp: "Seguir WhatsApp",
      themeLight: "Claro",
      themeDark: "Escuro",
      includeHistory: "Incluir hist\xF3rico de mensagens (beta)",
      disconnectLocal: "Apagar a sess\xE3o local ap\xF3s importar",
      cleanupNoticeHTML: "<strong>Aten\xE7\xE3o:</strong> esta sess\xE3o ser\xE1 migrada para a assinatura informada e desconectada deste navegador.",
      keepLocalSessionWarningHTML: "<strong>Risco:</strong> manter a sess\xE3o neste navegador e na inst\xE2ncia ao mesmo tempo roda a mesma conta em dois lugares, o que pode causar desconex\xF5es, perda de mensagens e outros bugs. Use apenas para depura\xE7\xE3o.",
      extensionInvalidated: "A extens\xE3o foi atualizada ou recarregada. Recarregue esta aba do WhatsApp Web e tente novamente."
    }
  };

  // src/shared/config.ts
  var CLIENT_BASE_DOMAIN = EXTENSION_CUSTOMIZATION.api.clientBaseDomain;
  var WHATSAPP_WEB_ORIGIN = EXTENSION_CUSTOMIZATION.whatsappWebOrigin;
  var WHATSAPP_WEB_URL_PREFIX = `${WHATSAPP_WEB_ORIGIN}/`;
  var IMPORT_CHUNK_ITEMS = EXTENSION_CUSTOMIZATION.importLimits.chunkItems;
  var IMPORT_HISTORY_CHAT_LIMIT = EXTENSION_CUSTOMIZATION.importLimits.historyChatLimit;
  var DEFAULT_INCLUDE_HISTORY = EXTENSION_CUSTOMIZATION.importDefaults.includeHistory;
  var API_AUTH_HEADER_NAME = EXTENSION_CUSTOMIZATION.api.authHeaderName;
  var APP_BRIDGE_SOURCE = EXTENSION_CUSTOMIZATION.appBridge.source;
  var APP_BRIDGE_MATCHES = [...EXTENSION_CUSTOMIZATION.appBridge.matches];
  var AUTOFILL_PARAMS = {
    client: "client",
    token: "token",
    includeHistory: "includeHistory",
    history: "history",
    historico: "historico",
    hideHistoryOption: "hideHistoryOption",
    hideHistory: "hideHistory",
    lockHistoryOption: "lockHistoryOption",
    lockHistory: "lockHistory",
    showClientField: "showClientField",
    hideClientField: "hideClientField",
    canEditClient: "canEditClient",
    lockClientField: "lockClientField",
    showTokenField: "showTokenField",
    hideTokenField: "hideTokenField",
    canEditToken: "canEditToken",
    lockTokenField: "lockTokenField",
    panelLayout: "panelLayout",
    layout: "layout"
  };
  var STORAGE_KEYS = {
    serverUrl: "serverUrl",
    instanceToken: "instanceToken",
    includeHistory: "includeHistory",
    disconnectLocal: "disconnectLocal",
    bridgeImportRequest: "bridgeImportRequest",
    devMode: "devMode",
    userSettings: "userSettings"
  };
  var PORT_NAMES = {
    sessionImport: "session-import"
  };
  var BACKGROUND_COMMANDS = {
    startImport: "START_IMPORT",
    importHistoryOnly: "IMPORT_HISTORY_ONLY",
    diagnose: "DIAGNOSE",
    dumpHistory: "DUMP_HISTORY",
    dumpSession: "DUMP_SESSION"
  };
  var PORT_MESSAGE_TYPES = {
    status: "STATUS",
    done: "DONE",
    error: "ERROR"
  };
  var CONTENT_MESSAGE_TYPES = {
    openPanel: "SESSION_CONNECTOR_OPEN_PANEL"
  };
  var APP_BRIDGE_MESSAGE_TYPES = {
    ready: "CONNECTOR_READY",
    ping: "PING",
    startImport: "START_IMPORT",
    openWhatsApp: "OPEN_WHATSAPP",
    started: "IMPORT_TAB_OPENED",
    error: "IMPORT_TAB_ERROR"
  };
  var API_PATHS = {
    instanceStatus: EXTENSION_CUSTOMIZATION.api.paths.instanceStatus,
    importWebSessionStart: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionStart,
    importWebSessionChunk: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionChunk,
    importWebSessionFinish: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionFinish,
    importWebSessionHistory: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionHistory
  };
  var WHATSAPP_LOGGED_IN_SELECTORS = [
    "#side",
    "#pane-side",
    '[data-testid="chat-list"]',
    '[data-testid="conversation-panel-wrapper"]',
    '[aria-label="Chat list"]',
    '[aria-label="Lista de conversas"]',
    '[aria-label="Chats"]',
    '[aria-label="Conversas"]'
  ];

  // src/shared/url.ts
  var AUTOFILL_PARAM_GROUPS = {
    client: [AUTOFILL_PARAMS.client],
    token: [AUTOFILL_PARAMS.token],
    includeHistory: [
      AUTOFILL_PARAMS.includeHistory,
      AUTOFILL_PARAMS.history,
      AUTOFILL_PARAMS.historico
    ],
    hideHistoryOption: [
      AUTOFILL_PARAMS.hideHistoryOption,
      AUTOFILL_PARAMS.hideHistory
    ],
    lockHistoryOption: [
      AUTOFILL_PARAMS.lockHistoryOption,
      AUTOFILL_PARAMS.lockHistory
    ],
    showClientField: [AUTOFILL_PARAMS.showClientField],
    hideClientField: [AUTOFILL_PARAMS.hideClientField],
    canEditClient: [AUTOFILL_PARAMS.canEditClient],
    lockClientField: [AUTOFILL_PARAMS.lockClientField],
    showTokenField: [AUTOFILL_PARAMS.showTokenField],
    hideTokenField: [AUTOFILL_PARAMS.hideTokenField],
    canEditToken: [AUTOFILL_PARAMS.canEditToken],
    lockTokenField: [AUTOFILL_PARAMS.lockTokenField],
    panelLayout: [
      AUTOFILL_PARAMS.panelLayout,
      AUTOFILL_PARAMS.layout
    ]
  };
  var AUTOFILL_PARAM_NAMES = Array.from(new Set(Object.values(AUTOFILL_PARAM_GROUPS).flat()));
  function normalizeClientHost(value) {
    const host = String(value || "").trim().toLowerCase().replace(/^@+/, "").replace(/\/.*$/, "").replace(/^\.+|\.+$/g, "");
    if (!host) {
      return "";
    }
    if (!/^[a-z0-9][a-z0-9.-]*(?::[0-9]{1,5})?$/.test(host)) {
      throw new Error("Nome da assinatura invalido. Use exatamente o nome da assinatura ou uma URL completa.");
    }
    return host;
  }
  function isLocalHost(host) {
    return host === "localhost" || host.startsWith("localhost:") || host.startsWith("127.");
  }
  function normalizeBaseUrl(value) {
    const raw = String(value || "").trim().replace(/\/+$/, "");
    if (!raw) {
      return "";
    }
    if (/^https?:\/\//i.test(raw)) {
      let url;
      try {
        url = new URL(raw);
      } catch {
        throw new Error("URL da instancia invalida.");
      }
      if (url.protocol !== "https:") {
        throw new Error("Use uma URL HTTPS do backend autorizado.");
      }
      if (isLocalHost(url.host)) {
        throw new Error("Use um backend autorizado publico com HTTPS.");
      }
      return raw;
    }
    const host = normalizeClientHost(raw);
    if (!host) {
      return "";
    }
    if (isLocalHost(host)) {
      throw new Error("Use um backend autorizado publico com HTTPS.");
    }
    if (host.includes(".")) {
      return `https://${host}`;
    }
    if (!CLIENT_BASE_DOMAIN) {
      throw new Error("Informe a URL HTTPS completa do backend autorizado.");
    }
    return `https://${host}.${CLIENT_BASE_DOMAIN}`;
  }

  // src/background/chunks.ts
  function countRows(value) {
    return Array.isArray(value) ? value.length : 0;
  }
  function appStateCollectionVersionKey(value) {
    const collection = String(value?.collection || "").trim();
    const version = Number(value?.version || 0);
    if (!collection || !Number.isFinite(version) || version <= 0) {
      return "";
    }
    return `${collection}\0${Math.floor(version)}`;
  }
  function countAppStateMutationMacsWithVersions(payload) {
    const versionKeys = new Set(
      (Array.isArray(payload?.appStateVersions) ? payload.appStateVersions : []).map(appStateCollectionVersionKey).filter(Boolean)
    );
    if (versionKeys.size === 0) {
      return 0;
    }
    return (Array.isArray(payload?.appStateMutationMacs) ? payload.appStateMutationMacs : []).filter((mac) => versionKeys.has(appStateCollectionVersionKey(mac))).length;
  }
  function countExpectedRows(payload) {
    return {
      preKeys: countRows(payload.preKeys),
      identityKeys: countRows(payload.identities),
      sessions: countRows(payload.sessions),
      senderKeys: countRows(payload.senderKeys),
      appStateSyncKeys: countRows(payload.appStateSyncKeys),
      appStateVersions: countRows(payload.appStateVersions),
      appStateMutationMACs: countAppStateMutationMacsWithVersions(payload),
      contacts: countRows(payload.contacts),
      privacyTokens: countRows(payload.privacyTokens),
      nctSalt: payload.nctSalt ? 1 : 0,
      validatedHistoryChats: countRows(payload.history?.chats),
      validatedHistoryMessages: countRows(payload.history?.messages)
    };
  }
  function pushArrayChunks(chunks, section, key, rows, limit = IMPORT_CHUNK_ITEMS) {
    if (!Array.isArray(rows) || rows.length === 0) {
      return;
    }
    for (let index = 0; index < rows.length; index += limit) {
      const slice = rows.slice(index, index + limit);
      chunks.push({ section, count: slice.length, payload: { [key]: slice } });
    }
  }
  function pushHistoryChunks(chunks, section, key, rows, limit = IMPORT_CHUNK_ITEMS) {
    if (!Array.isArray(rows) || rows.length === 0) {
      return;
    }
    for (let index = 0; index < rows.length; index += limit) {
      const slice = rows.slice(index, index + limit);
      chunks.push({ section, count: slice.length, payload: { history: { [key]: slice } } });
    }
  }
  function buildAppStateChunks(payload) {
    const versions = Array.isArray(payload.appStateVersions) ? payload.appStateVersions : [];
    const macs = Array.isArray(payload.appStateMutationMacs) ? payload.appStateMutationMacs : [];
    if (versions.length === 0 && macs.length === 0) {
      return [];
    }
    const macsByVersion = /* @__PURE__ */ new Map();
    for (const mac of macs) {
      const key = appStateCollectionVersionKey(mac);
      if (!key) {
        continue;
      }
      if (!macsByVersion.has(key)) {
        macsByVersion.set(key, []);
      }
      macsByVersion.get(key)?.push(mac);
    }
    if (versions.length === 0) {
      return [];
    }
    return versions.map((version) => {
      const key = appStateCollectionVersionKey(version);
      const versionMacs = macsByVersion.get(key) || [];
      return {
        section: "appState",
        count: 1 + versionMacs.length,
        payload: { appStateVersions: [version], appStateMutationMacs: versionMacs }
      };
    });
  }
  function buildImportChunks(payload) {
    const chunks = [];
    pushArrayChunks(chunks, "sessions", "sessions", payload.sessions);
    pushArrayChunks(chunks, "identities", "identities", payload.identities);
    pushArrayChunks(chunks, "senderKeys", "senderKeys", payload.senderKeys);
    pushArrayChunks(chunks, "preKeys", "preKeys", payload.preKeys);
    pushArrayChunks(chunks, "appStateSyncKeys", "appStateSyncKeys", payload.appStateSyncKeys);
    chunks.push(...buildAppStateChunks(payload));
    pushArrayChunks(chunks, "contacts", "contacts", payload.contacts);
    pushArrayChunks(chunks, "privacyTokens", "privacyTokens", payload.privacyTokens);
    if (payload.nctSalt) {
      chunks.push({ section: "nctSalt", count: 1, payload: { nctSalt: payload.nctSalt } });
    }
    pushHistoryChunks(chunks, "historyChats", "chats", payload.history?.chats);
    pushHistoryChunks(chunks, "historyMessages", "messages", payload.history?.messages);
    return chunks;
  }

  // src/background/api.ts
  async function sha256Hex(text) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  async function encodeRequestBody(json) {
    if (!("CompressionStream" in globalThis)) {
      return { body: json, encoding: "" };
    }
    const stream = new Blob([json], { type: "application/json" }).stream().pipeThrough(new CompressionStream("gzip"));
    return { body: await new Response(stream).arrayBuffer(), encoding: "gzip" };
  }
  function authHeaders(token) {
    return { [API_AUTH_HEADER_NAME]: token };
  }
  async function postJSON(url, token, payload, failureLabel) {
    const json = JSON.stringify(payload);
    const encoded = await encodeRequestBody(json);
    const headers = {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...authHeaders(token)
    };
    if (encoded.encoding) {
      headers["Content-Encoding"] = encoded.encoding;
    }
    const response = await fetch(url, { method: "POST", headers, body: encoded.body });
    const text = await response.text();
    let body = {};
    try {
      body = text ? JSON.parse(text) : {};
    } catch {
      body = { raw: text };
    }
    if (!response.ok) {
      const reason = body.error || body.message || text || `HTTP ${response.status}`;
      throw new Error(`${failureLabel}: ${reason}`);
    }
    return body;
  }
  async function postJSONWithRetry(url, token, payload, failureLabel) {
    let lastError;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        return await postJSON(url, token, payload, failureLabel);
      } catch (error) {
        lastError = error;
        await new Promise((resolve) => setTimeout(resolve, 500 * (attempt + 1)));
      }
    }
    throw lastError;
  }
  async function getJSON(url, token, failureLabel) {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        ...authHeaders(token)
      }
    });
    const text = await response.text();
    let body = {};
    try {
      body = text ? JSON.parse(text) : {};
    } catch {
      body = { raw: text };
    }
    if (!response.ok) {
      const reason = body.error || body.message || text || `HTTP ${response.status}`;
      throw new Error(`${failureLabel}: ${reason}`);
    }
    return body;
  }
  async function verifyInstanceForImport(serverUrl, token) {
    const payload = await getJSON(`${normalizeBaseUrl(serverUrl)}${API_PATHS.instanceStatus}`, token, "Falha ao validar inst\xE2ncia");
    const status = payload.status || {};
    const instanceStatus = String(payload.instance?.status || "").trim().toLowerCase();
    const importableStatuses = /* @__PURE__ */ new Set(["disconnected", "importing"]);
    if (status.connected || status.loggedIn || instanceStatus && !importableStatuses.has(instanceStatus)) {
      throw new Error(`A inst\xE2ncia precisa estar desconectada antes da importa\xE7\xE3o (status atual: ${instanceStatus || "ativa"})`);
    }
    return payload;
  }
  async function startImportJob(baseUrl, token, payload) {
    const start = await postJSONWithRetry(
      `${baseUrl}${API_PATHS.importWebSessionStart}`,
      token,
      {
        device: payload.device,
        expected: countExpectedRows(payload)
      },
      "Falha ao iniciar importa\xE7\xE3o"
    );
    const jobId = start.jobId || start.job_id;
    if (!jobId) {
      throw new Error("API n\xE3o retornou jobId");
    }
    return jobId;
  }
  async function sendImportChunk(baseUrl, token, jobId, seq, total, chunk) {
    const chunkPayloadJSON = JSON.stringify(chunk.payload);
    await postJSONWithRetry(
      `${baseUrl}${API_PATHS.importWebSessionChunk}`,
      token,
      {
        jobId,
        section: chunk.section,
        seq,
        count: chunk.count,
        sha256: await sha256Hex(chunkPayloadJSON),
        payload: chunk.payload
      },
      `Falha ao enviar chunk ${seq + 1}/${total}`
    );
  }
  async function finishImportJob(baseUrl, token, jobId) {
    return postJSONWithRetry(
      `${baseUrl}${API_PATHS.importWebSessionFinish}`,
      token,
      { jobId },
      "Falha ao finalizar importa\xE7\xE3o"
    );
  }
  async function uploadWhatsmeowPayload(serverUrl, token, payload, options = {}) {
    const baseUrl = normalizeBaseUrl(serverUrl);
    const jobId = await startImportJob(baseUrl, token, payload);
    const chunks = buildImportChunks(payload);
    for (let seq = 0; seq < chunks.length; seq += 1) {
      const chunk = chunks[seq];
      await sendImportChunk(baseUrl, token, jobId, seq, chunks.length, chunk);
      options.onProgress?.(seq + 1, chunks.length, chunk.section);
    }
    return finishImportJob(baseUrl, token, jobId);
  }
  async function uploadHistoryOnlyPayload(serverUrl, token, payload) {
    return postJSONWithRetry(
      `${normalizeBaseUrl(serverUrl)}${API_PATHS.importWebSessionHistory}`,
      token,
      payload,
      "Falha ao repassar hist\xF3rico"
    );
  }

  // src/background/conversion.ts
  function firstDefined(...values) {
    for (const value of values) {
      if (value !== void 0 && value !== null) {
        return value;
      }
    }
    return void 0;
  }
  function mergeByKey(existing, incoming, keyFn) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const item of [...existing || [], ...incoming || []]) {
      const key = keyFn(item);
      if (!key || seen.has(key)) {
        continue;
      }
      seen.add(key);
      out.push(item);
    }
    return out;
  }
  function mergeContactsByJID(existing, incoming) {
    const byJID = /* @__PURE__ */ new Map();
    for (const item of [...existing || [], ...incoming || []]) {
      const jid = normalizeHistoryJID(item?.jid);
      if (!jid) {
        continue;
      }
      const previous = byJID.get(jid);
      if (!previous) {
        byJID.set(jid, { ...item, jid });
        continue;
      }
      const merged = { ...previous, jid };
      for (const [key, value] of Object.entries(item)) {
        if (key === "jid" || value === void 0 || value === null || String(value).trim() === "") {
          continue;
        }
        merged[key] = value;
      }
      byJID.set(jid, merged);
    }
    return Array.from(byJID.values());
  }
  function normalizeHistoryTimestampMs(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric <= 0) {
      return 0;
    }
    return numeric < 1e11 ? Math.floor(numeric * 1e3) : Math.floor(numeric);
  }
  function normalizeHistoryJID(value) {
    if (!value) {
      return "";
    }
    let raw = "";
    if (typeof value === "string") {
      raw = value;
    } else if (typeof value === "object") {
      if (typeof value._serialized === "string") {
        raw = value._serialized;
      } else if (typeof value.user === "string" && typeof value.server === "string") {
        raw = `${value.user}@${value.server}`;
      } else if (typeof value.toString === "function" && value.toString !== Object.prototype.toString) {
        const serialized = value.toString();
        if (typeof serialized === "string" && serialized.includes("@")) {
          raw = serialized;
        }
      }
    }
    const trimmed = String(raw || "").trim();
    const at = trimmed.lastIndexOf("@");
    if (at < 0) {
      return trimmed;
    }
    const server = trimmed.slice(at + 1);
    if (server === "c.us") {
      return `${trimmed.slice(0, at)}@s.whatsapp.net`;
    }
    return trimmed;
  }
  function historyJIDIdentityKey(value) {
    const jid = normalizeHistoryJID(value);
    const at = jid.lastIndexOf("@");
    if (at < 0) {
      return jid;
    }
    const server = jid.slice(at + 1);
    const user = jid.slice(0, at).replace(/:.+$/, "");
    return `${user}@${server}`;
  }
  function historyJIDMatchesAny(value, candidates) {
    const key = historyJIDIdentityKey(value);
    if (!key) {
      return false;
    }
    return candidates.some((candidate) => key === historyJIDIdentityKey(candidate));
  }
  function isPrivateHistoryJID(value) {
    const jid = normalizeHistoryJID(value);
    return jid.endsWith("@s.whatsapp.net") || jid.endsWith("@c.us") || jid.endsWith("@lid");
  }
  function historyJIDUser(value) {
    const jid = normalizeHistoryJID(value);
    const at = jid.lastIndexOf("@");
    if (at < 0) {
      return "";
    }
    return jid.slice(0, at).replace(/:.+$/, "");
  }
  function isLIDHistoryJID(value) {
    return normalizeHistoryJID(value).endsWith("@lid");
  }
  function isPNHistoryJID(value) {
    return normalizeHistoryJID(value).endsWith("@s.whatsapp.net");
  }
  function buildHistoryLIDToPNMap(contacts) {
    const out = /* @__PURE__ */ new Map();
    for (const contact of Array.isArray(contacts) ? contacts : []) {
      const lid = normalizeHistoryJID(contact?.lid || (isLIDHistoryJID(contact?.jid) ? contact?.jid : ""));
      const pn = normalizeHistoryJID(contact?.jid || contact?.phoneNumber);
      if (!isLIDHistoryJID(lid) || !isPNHistoryJID(pn)) {
        continue;
      }
      const lidUser = historyJIDUser(lid);
      if (lidUser && !out.has(lidUser)) {
        out.set(lidUser, pn);
      }
    }
    return out;
  }
  function mapHistoryJIDWithLIDMap(value, lidToPN) {
    const jid = normalizeHistoryJID(value);
    if (!isLIDHistoryJID(jid) || !(lidToPN instanceof Map)) {
      return jid;
    }
    return lidToPN.get(historyJIDUser(jid)) || jid;
  }
  function normalizeHistoryJIDsWithContactLIDMap(history, contacts) {
    if (!history || typeof history !== "object") {
      return history;
    }
    const lidToPN = buildHistoryLIDToPNMap(contacts);
    if (lidToPN.size === 0) {
      return history;
    }
    const chats = (Array.isArray(history.chats) ? history.chats : []).map((chat) => {
      const rawJid = normalizeHistoryJID(chat?.jid);
      const rawLid = normalizeHistoryJID(chat?.lid);
      const mappedJid = mapHistoryJIDWithLIDMap(rawJid, lidToPN);
      const lid = rawLid || (isLIDHistoryJID(rawJid) ? rawJid : "");
      return {
        ...chat,
        ...mappedJid ? { jid: mappedJid } : {},
        ...lid ? { lid } : {}
      };
    });
    const messages = (Array.isArray(history.messages) ? history.messages : []).map((message) => {
      const chatJid = mapHistoryJIDWithLIDMap(message?.chatJid, lidToPN);
      const senderJid = mapHistoryJIDWithLIDMap(message?.senderJid, lidToPN);
      return {
        ...message,
        ...chatJid ? { chatJid } : {},
        ...senderJid ? { senderJid } : {}
      };
    });
    return { ...history, chats, messages };
  }
  function historyBoolean(value) {
    return value === true || value === "true" || value === 1;
  }
  function historyPeerJIDFromEndpoints({ fromMe, fromJid, toJid, ownerJids }) {
    const from = normalizeHistoryJID(fromJid);
    const to = normalizeHistoryJID(toJid);
    const owners = (Array.isArray(ownerJids) ? ownerJids : []).map(normalizeHistoryJID).filter(Boolean);
    if (owners.length > 0) {
      const fromIsOwner = historyJIDMatchesAny(from, owners);
      const toIsOwner = historyJIDMatchesAny(to, owners);
      if (fromIsOwner && to && !toIsOwner) {
        return to;
      }
      if (toIsOwner && from && !fromIsOwner) {
        return from;
      }
    }
    return historyBoolean(fromMe) ? to || from : from || to;
  }
  function repairedHistoryWebMessage(message, chatJid, senderJid) {
    const webMessage = message?.webMessage;
    if (!webMessage || typeof webMessage !== "object" || Array.isArray(webMessage)) {
      return webMessage;
    }
    const output = { ...webMessage };
    const key = webMessage.key && typeof webMessage.key === "object" && !Array.isArray(webMessage.key) ? { ...webMessage.key } : {};
    if (Object.keys(key).length > 0) {
      key.remoteJID = chatJid;
      key.fromMe = historyBoolean(message.fromMe);
      if (message.id) {
        key.ID = message.id;
      }
      if (chatJid.endsWith("@g.us") && senderJid) {
        key.participant = senderJid;
      } else {
        delete key.participant;
      }
      output.key = key;
    }
    if (chatJid.endsWith("@g.us") && senderJid) {
      output.participant = senderJid;
    } else {
      delete output.participant;
    }
    return output;
  }
  function repairHistoryPeerJids(history, ownerJids) {
    if (!history || typeof history !== "object") {
      return history;
    }
    const owners = (Array.isArray(ownerJids) ? ownerJids : [ownerJids]).map(normalizeHistoryJID).filter(Boolean);
    if (owners.length === 0) {
      return history;
    }
    const messages = (Array.isArray(history.messages) ? history.messages : []).map((message) => {
      if (!message || typeof message !== "object") {
        return message;
      }
      const sourceFromJid = normalizeHistoryJID(message._sourceFromJid || message.sourceFromJid);
      const sourceToJid = normalizeHistoryJID(message._sourceToJid || message.sourceToJid);
      const fromMe = historyBoolean(message.fromMe);
      const peerJid = historyPeerJIDFromEndpoints({
        fromMe,
        fromJid: sourceFromJid,
        toJid: sourceToJid,
        ownerJids: owners
      });
      let chatJid = normalizeHistoryJID(message.chatJid);
      const shouldUsePeer = peerJid && !historyJIDMatchesAny(peerJid, owners) && (!chatJid || historyJIDMatchesAny(chatJid, owners));
      if (shouldUsePeer) {
        chatJid = peerJid;
      }
      let senderJid = normalizeHistoryJID(message.senderJid);
      if (!fromMe && isPrivateHistoryJID(chatJid) && (!senderJid || historyJIDMatchesAny(senderJid, owners))) {
        senderJid = chatJid;
      }
      const repaired = {
        ...message,
        chatJid,
        senderJid,
        fromMe,
        webMessage: repairedHistoryWebMessage({ ...message, chatJid, senderJid, fromMe }, chatJid, senderJid)
      };
      delete repaired._sourceFromJid;
      delete repaired._sourceToJid;
      delete repaired.sourceFromJid;
      delete repaired.sourceToJid;
      return repaired;
    });
    return { ...history, messages };
  }
  function limitHistoryAnchors(history, limit = IMPORT_HISTORY_CHAT_LIMIT) {
    if (!history || typeof history !== "object") {
      return history;
    }
    const rawChats = Array.isArray(history.chats) ? history.chats : [];
    const rawMessages = Array.isArray(history.messages) ? history.messages : [];
    const latestMessageByChat = /* @__PURE__ */ new Map();
    const messagesByChat = /* @__PURE__ */ new Map();
    const seenMessages = /* @__PURE__ */ new Set();
    for (const message of rawMessages) {
      const chatJid = String(message?.chatJid || "").trim();
      const id = String(message?.id || "").trim();
      if (!chatJid || !id) {
        continue;
      }
      const messageKey = `${chatJid}\0${id}`;
      if (seenMessages.has(messageKey)) {
        continue;
      }
      seenMessages.add(messageKey);
      const normalized = { ...message, id, chatJid, timestampMs: normalizeHistoryTimestampMs(message.timestampMs) };
      if (!messagesByChat.has(chatJid)) {
        messagesByChat.set(chatJid, []);
      }
      messagesByChat.get(chatJid).push(normalized);
      const existing = latestMessageByChat.get(chatJid);
      if (!existing || normalized.timestampMs > Number(existing.timestampMs || 0)) {
        latestMessageByChat.set(chatJid, normalized);
      }
    }
    const chatByJid = /* @__PURE__ */ new Map();
    for (const chat of rawChats) {
      const jid = String(chat?.jid || "").trim();
      if (!jid) {
        continue;
      }
      const normalized = {
        ...chat,
        jid,
        lid: String(chat?.lid || "").trim(),
        lastMessageTimestampMs: normalizeHistoryTimestampMs(chat.lastMessageTimestampMs)
      };
      const existing = chatByJid.get(jid);
      if (!existing || normalized.lastMessageTimestampMs > normalizeHistoryTimestampMs(existing.lastMessageTimestampMs)) {
        chatByJid.set(jid, normalized);
      }
    }
    const hasChatForMessageJID = (jid) => {
      if (chatByJid.has(jid)) {
        return true;
      }
      for (const chat of chatByJid.values()) {
        if (String(chat?.lid || "").trim() === jid) {
          return true;
        }
      }
      return false;
    };
    for (const message of latestMessageByChat.values()) {
      if (!hasChatForMessageJID(message.chatJid)) {
        chatByJid.set(message.chatJid, {
          jid: message.chatJid,
          isGroup: message.chatJid.endsWith("@g.us"),
          lastMessageTimestampMs: normalizeHistoryTimestampMs(message.timestampMs)
        });
      }
    }
    const latestMessageForChat = (chat) => {
      let latest = null;
      for (const chatKey of [chat?.jid, chat?.lid].filter(Boolean)) {
        const candidate = latestMessageByChat.get(chatKey);
        if (!candidate) {
          continue;
        }
        if (!latest || Number(candidate.timestampMs || 0) > Number(latest.timestampMs || 0)) {
          latest = candidate;
        }
      }
      return latest;
    };
    const chats = Array.from(chatByJid.values()).filter(
      (chat) => [chat.jid, chat.lid].filter(Boolean).some((chatKey) => messagesByChat.has(chatKey))
    );
    chats.sort((left, right) => {
      const leftMessage = latestMessageForChat(left);
      const rightMessage = latestMessageForChat(right);
      const leftTimestamp = Math.max(
        normalizeHistoryTimestampMs(left.lastMessageTimestampMs),
        Number(leftMessage?.timestampMs || 0)
      );
      const rightTimestamp = Math.max(
        normalizeHistoryTimestampMs(right.lastMessageTimestampMs),
        Number(rightMessage?.timestampMs || 0)
      );
      return rightTimestamp - leftTimestamp;
    });
    const selectedChats = chats.slice(0, Math.max(0, limit));
    const selectedMessages = [];
    const selectedMessageKeys = /* @__PURE__ */ new Set();
    for (const chat of selectedChats) {
      const message = latestMessageForChat(chat);
      if (!message) {
        continue;
      }
      const messageKey = `${message.chatJid}\0${message.id}`;
      if (!selectedMessageKeys.has(messageKey)) {
        selectedMessageKeys.add(messageKey);
        selectedMessages.push(message);
      }
    }
    selectedMessages.sort((left, right) => Number(right.timestampMs || 0) - Number(left.timestampMs || 0));
    return { chats: selectedChats, messages: selectedMessages };
  }
  function bytesToBase64Browser(value) {
    if (!value) {
      return "";
    }
    if (typeof value === "string") {
      return value.trim();
    }
    if (value instanceof Uint8Array) {
      let binary = "";
      const step = 32768;
      for (let index = 0; index < value.length; index += step) {
        binary += String.fromCharCode.apply(null, value.subarray(index, index + step));
      }
      return btoa(binary);
    }
    if (Array.isArray(value)) {
      return bytesToBase64Browser(new Uint8Array(value));
    }
    if (value && value.type === "Buffer") {
      if (typeof value.data === "string") {
        return value.data.trim();
      }
      if (Array.isArray(value.data)) {
        return bytesToBase64Browser(new Uint8Array(value.data));
      }
    }
    return "";
  }
  function normalizeContactPhoneJID(value) {
    const jid = normalizeHistoryJID(value);
    if (!jid) {
      return "";
    }
    if (jid.endsWith("@s.whatsapp.net")) {
      return jid;
    }
    if (jid.includes("@")) {
      return "";
    }
    const digits = jid.replace(/\D/g, "");
    return digits ? `${digits}@s.whatsapp.net` : "";
  }
  function normalizeContactForWhatsmeow(row) {
    const rawJid = normalizeHistoryJID(row?.jid || row?.id);
    const phoneJid = normalizeContactPhoneJID(row?.phoneNumber);
    const jid = phoneJid || rawJid;
    if (!jid) {
      return null;
    }
    const rawLid = normalizeHistoryJID(row?.lid || row?.accountLid);
    const lid = rawLid || (rawJid.endsWith("@lid") ? rawJid : "");
    return {
      jid,
      ...lid ? { lid } : {},
      ...row.firstName || row.shortName || row.formattedShortName ? { firstName: String(row.firstName || row.shortName || row.formattedShortName).trim() } : {},
      ...row.fullName || row.displayName || row.name || row.formattedName || row.formattedTitle ? { fullName: String(row.fullName || row.displayName || row.name || row.formattedName || row.formattedTitle).trim() } : {},
      ...row.pushName || row.pushname || row.notifyName || row.notify || row.senderName ? { pushName: String(row.pushName || row.pushname || row.notifyName || row.notify || row.senderName).trim() } : {},
      ...row.businessName || row.verifiedName || row.verifiedNameForDisplay || row.displayBusinessName ? { businessName: String(row.businessName || row.verifiedName || row.verifiedNameForDisplay || row.displayBusinessName).trim() } : {},
      ...row.redactedPhone ? { redactedPhone: String(row.redactedPhone).trim() } : {}
    };
  }
  function normalizePrivacyTokenForWhatsmeow(row) {
    const userJid = String(row?.userJid || row?.jid || "").trim();
    const token = bytesToBase64Browser(row?.token);
    const timestampS = Number.isFinite(row?.timestampS) ? Math.floor(row.timestampS) : Math.floor(Number(row?.timestampMs || 0) / 1e3);
    if (!userJid || !token || !timestampS) {
      return null;
    }
    const senderTimestampS = Number.isFinite(row?.senderTimestampS) ? Math.floor(row.senderTimestampS) : Number.isFinite(row?.senderTimestampMs) ? Math.floor(row.senderTimestampMs / 1e3) : void 0;
    return {
      userJid,
      token,
      timestampS,
      ...senderTimestampS ? { senderTimestampS } : {}
    };
  }
  function normalizeRows(source, key, mapper) {
    const rows = Array.isArray(source?.[key]) ? source[key] : [];
    return rows.map(mapper).filter(Boolean);
  }
  function attachSidecarPayload(whatsmeowPayload, sidecar, waWebDump) {
    const output = { ...whatsmeowPayload };
    const sources = [sidecar, waWebDump].filter(Boolean);
    const baseContacts = normalizeRows(output, "contacts", normalizeContactForWhatsmeow);
    const contacts = sources.flatMap((source) => normalizeRows(source, "contacts", normalizeContactForWhatsmeow));
    if (baseContacts.length > 0 || contacts.length > 0) {
      output.contacts = mergeContactsByJID(baseContacts, contacts);
    }
    const basePrivacyTokens = normalizeRows(output, "privacyTokens", normalizePrivacyTokenForWhatsmeow);
    const privacyTokens = sources.flatMap((source) => normalizeRows(source, "privacyTokens", normalizePrivacyTokenForWhatsmeow));
    if (basePrivacyTokens.length > 0 || privacyTokens.length > 0) {
      output.privacyTokens = mergeByKey(basePrivacyTokens, privacyTokens, (item) => item.userJid);
    }
    const history = firstDefined(...sources.map((source) => source.history));
    if (history && typeof history === "object") {
      const repairedHistory = limitHistoryAnchors(repairHistoryPeerJids(history, [
        output.device?.meJid,
        output.device?.meLid,
        ...sources.flatMap((source) => [source.device?.meJid, source.device?.meLid])
      ]));
      output.history = normalizeHistoryJIDsWithContactLIDMap(repairedHistory, output.contacts);
    }
    const nctSalt = firstDefined(...sources.map((source) => source.nctSalt));
    if (typeof nctSalt === "string" && nctSalt.trim()) {
      output.nctSalt = nctSalt.trim();
    }
    delete output.deviceLists;
    delete output.lidMappings;
    return output;
  }
  function buildWhatsmeowPayload(mainDump, sidecar) {
    if (!globalThis.WAStoreMigrate) {
      throw new Error("Conversor wa-store-migrate n\xE3o carregado");
    }
    const waWebDump = WAStoreMigrate.coerceBufferJson(mainDump);
    const migrated = WAStoreMigrate.migrate({
      from: "wa-web",
      to: "whatsmeow",
      data: waWebDump,
      validate: false
    });
    return {
      payload: attachSidecarPayload(WAStoreMigrate.snapshot.toJSON("whatsmeow", migrated.snapshot), sidecar, waWebDump),
      losses: migrated.losses
    };
  }

  // src/background/payload.ts
  function importPayloadForOptions(payload, options = {}) {
    const skipsHistory = options.includeHistory === false;
    if (!skipsHistory) {
      return payload;
    }
    const copy = { ...payload };
    delete copy.history;
    delete copy.contacts;
    return copy;
  }

  // src/background/page-scripts/clear-local-session.ts
  function clearWhatsAppWebLocalSessionData() {
    function deleteDatabase(name) {
      return new Promise((resolve) => {
        const request = indexedDB.deleteDatabase(name);
        request.onsuccess = () => resolve({ name, deleted: true });
        request.onerror = () => resolve({ name, deleted: false, error: request.error ? request.error.message : "delete failed" });
        request.onblocked = () => resolve({ name, deleted: false, blocked: true });
      });
    }
    async function run() {
      const localStorageKeys = Object.keys(localStorage || {});
      const sessionStorageKeys = Object.keys(sessionStorage || {});
      localStorage.clear();
      sessionStorage.clear();
      let databaseNames = [];
      if (indexedDB.databases) {
        const databases = await indexedDB.databases();
        databaseNames = databases.map((database) => database && database.name).filter(Boolean);
      }
      for (const name of ["signal-storage", "model-storage", "wawc_db_enc"]) {
        if (!databaseNames.includes(name)) {
          databaseNames.push(name);
        }
      }
      const deletedDatabases = await Promise.all(databaseNames.map(deleteDatabase));
      let deletedCaches = [];
      if ("caches" in globalThis) {
        const cacheNames = await caches.keys();
        deletedCaches = await Promise.all(cacheNames.map(async (name) => ({ name, deleted: await caches.delete(name) })));
      }
      return {
        method: "page",
        localStorageKeys: localStorageKeys.length,
        sessionStorageKeys: sessionStorageKeys.length,
        indexedDB: deletedDatabases,
        caches: deletedCaches
      };
    }
    return run().then((summary) => ({ summary })).catch((error) => ({ error: error.message || "Falha ao limpar dados locais" }));
  }

  // src/background/page-scripts/extract-history.ts
  function extractWhatsAppWebSidecarDump(options = {}) {
    const configuredHistoryChatLimit = Number(options?.historyChatLimit);
    const HISTORY_CHAT_LIMIT = Number.isFinite(configuredHistoryChatLimit) && configuredHistoryChatLimit >= 0 ? Math.floor(configuredHistoryChatLimit) : 5e3;
    const LIMITS = {
      contacts: 15e3,
      chats: 1e4,
      messages: HISTORY_CHAT_LIMIT,
      messageScan: HISTORY_CHAT_LIMIT * 10,
      historyChats: HISTORY_CHAT_LIMIT
    };
    function openDatabase(name) {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open(name);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error(`Falha ao abrir ${name}`));
        request.onblocked = () => reject(new Error(`Abertura bloqueada: ${name}`));
      });
    }
    async function readStore(dbName, storeName, limit, direction = "next") {
      const db = await openDatabase(dbName);
      try {
        if (!Array.from(db.objectStoreNames || []).includes(storeName)) {
          return [];
        }
        const tx = db.transaction(storeName, "readonly");
        const store = tx.objectStore(storeName);
        const rows = [];
        await new Promise((resolve, reject) => {
          const request = store.openCursor(null, direction);
          request.onsuccess = () => {
            const cursor = request.result;
            if (!cursor || rows.length >= limit) {
              resolve();
              return;
            }
            rows.push(cursor.value);
            cursor.continue();
          };
          request.onerror = () => reject(request.error || new Error(`Falha ao ler ${storeName}`));
        });
        return rows;
      } finally {
        db.close();
      }
    }
    function getWaModule(name) {
      try {
        const pageRequire = globalThis.require;
        if (typeof pageRequire === "function") {
          return pageRequire(name);
        }
      } catch {
      }
      try {
        if (typeof __d === "function") {
          let captured;
          const sentinel = `__waSidecarProbe_${Math.random().toString(36).slice(2)}`;
          __d(sentinel, [name], function(_target, _namespace, _require, moduleRequire) {
            captured = moduleRequire(name);
          });
          if (!captured && typeof __d.require === "function") {
            captured = __d.require(name);
          }
          if (captured) {
            return captured;
          }
        }
      } catch {
      }
      return null;
    }
    function normalizeWhatsAppUserJID(value) {
      const trimmed = String(value || "").trim();
      const at = trimmed.lastIndexOf("@");
      if (at < 0) {
        return trimmed;
      }
      const server = trimmed.slice(at + 1);
      if (server === "c.us") {
        return `${trimmed.slice(0, at)}@s.whatsapp.net`;
      }
      return trimmed;
    }
    function jidToString(value) {
      if (!value) {
        return "";
      }
      if (typeof value === "string") {
        return normalizeWhatsAppUserJID(value);
      }
      if (typeof value === "object") {
        if (typeof value._serialized === "string") {
          return normalizeWhatsAppUserJID(value._serialized);
        }
        if (typeof value.user === "string" && typeof value.server === "string") {
          return normalizeWhatsAppUserJID(`${value.user}@${value.server}`);
        }
        if (typeof value.toString === "function" && value.toString !== Object.prototype.toString) {
          const serialized = value.toString();
          if (typeof serialized === "string" && serialized.includes("@")) {
            return normalizeWhatsAppUserJID(serialized);
          }
        }
      }
      return "";
    }
    function text(value) {
      if (typeof value === "string") {
        return value.trim();
      }
      return "";
    }
    function timestampMs(value) {
      if (!Number.isFinite(value) || value <= 0) {
        return 0;
      }
      return value < 1e11 ? Math.floor(value * 1e3) : Math.floor(value);
    }
    function messageIDToString(value) {
      if (!value) {
        return "";
      }
      if (typeof value === "object") {
        const nestedID = text(value.id);
        if (nestedID) {
          return nestedID;
        }
        const serialized = text(value._serialized);
        if (serialized) {
          return messageIDToString(serialized);
        }
      }
      if (typeof value !== "string") {
        return "";
      }
      const trimmed = value.trim();
      const parts = trimmed.split("_");
      if ((parts[0] === "true" || parts[0] === "false") && parts.length >= 3) {
        return parts[2];
      }
      return trimmed;
    }
    function messageChatJIDFromID(value) {
      if (!value) {
        return "";
      }
      if (typeof value === "object") {
        const remote = jidToString(value.remote);
        if (remote) {
          return remote;
        }
        const serialized = text(value._serialized);
        if (serialized) {
          return messageChatJIDFromID(serialized);
        }
      }
      if (typeof value !== "string") {
        return "";
      }
      const parts = value.trim().split("_");
      if ((parts[0] === "true" || parts[0] === "false") && parts.length >= 3) {
        return jidToString(parts[1]);
      }
      return "";
    }
    function bytesToUint8Array(value) {
      if (!value) {
        return null;
      }
      if (value instanceof Uint8Array) {
        return value;
      }
      if (value instanceof ArrayBuffer) {
        return new Uint8Array(value);
      }
      if (ArrayBuffer.isView(value)) {
        return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
      }
      if (Array.isArray(value)) {
        return new Uint8Array(value);
      }
      return null;
    }
    function bytesToBase64(value) {
      const bytes = bytesToUint8Array(value);
      if (!bytes || bytes.length === 0) {
        return "";
      }
      let binary = "";
      for (const byte of bytes) {
        binary += String.fromCharCode(byte);
      }
      return btoa(binary);
    }
    function compactObject(value) {
      return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== "" && item !== 0 && item !== void 0 && item !== null));
    }
    function firstDefined2(...values) {
      for (const value of values) {
        if (value !== void 0 && value !== null && value !== "") {
          return value;
        }
      }
      return void 0;
    }
    function firstText(...values) {
      for (const value of values) {
        const trimmed = text(value);
        if (trimmed) {
          return trimmed;
        }
      }
      return "";
    }
    function primitiveContentValue(value) {
      if (value === void 0 || value === null || value === "") {
        return void 0;
      }
      if (typeof value === "string") {
        return value.trim() || void 0;
      }
      if (typeof value === "number") {
        return Number.isFinite(value) ? value : void 0;
      }
      if (typeof value === "boolean") {
        return value;
      }
      if (value instanceof Uint8Array || value instanceof ArrayBuffer || ArrayBuffer.isView(value) || Array.isArray(value)) {
        return bytesToBase64(value) || void 0;
      }
      if (typeof value === "object" && typeof value.toNumber === "function") {
        const numeric = value.toNumber();
        return Number.isFinite(numeric) ? numeric : void 0;
      }
      return void 0;
    }
    function firstContentValue(...values) {
      for (const value of values) {
        const normalized = primitiveContentValue(value);
        if (normalized !== void 0 && normalized !== "") {
          return normalized;
        }
      }
      return void 0;
    }
    const MESSAGE_TEXT_FIELDS = /* @__PURE__ */ new Set([
      "body",
      "caption",
      "clienturl",
      "content",
      "contenttext",
      "conversation",
      "description",
      "eventdescription",
      "eventname",
      "footertext",
      "hydratedcontenttext",
      "hydratedfootertext",
      "hydratedtitletext",
      "loc",
      "matchedtext",
      "messagetext",
      "name",
      "paymentnotemsgbody",
      "pollname",
      "quarantineextractedtext",
      "selecteddisplaytext",
      "text",
      "title"
    ]);
    const MESSAGE_NESTED_FIELDS = [
      "message",
      "_message",
      "msg",
      "msgOpaqueData",
      "opaqueData",
      "plainText",
      "plaintext",
      "payload",
      "data",
      "extendedTextMessage",
      "imageMessage",
      "videoMessage",
      "documentMessage",
      "audioMessage",
      "stickerMessage",
      "buttonsMessage",
      "listMessage",
      "pollCreationMessage",
      "pollCreationMessageV2",
      "pollCreationMessageV3",
      "pollCreationMessageV4",
      "pollCreationMessageV5",
      "pollCreationMessageV6",
      "eventMessage",
      "locationMessage",
      "liveLocationMessage",
      "contactMessage",
      "contactsArrayMessage",
      "productMessage",
      "orderMessage",
      "templateMessage",
      "interactiveMessage",
      "interactiveResponseMessage"
    ];
    const MESSAGE_TEXT_EXCLUDED_FIELDS = /* @__PURE__ */ new Set([
      "contextInfo",
      "quotedMessage",
      "quotedMsg",
      "quotedPaymentInfo",
      "quotedStickerData",
      "statusQuotedMessage"
    ]);
    function normalizedFieldName(key) {
      return String(key || "").replace(/^__x_/, "").replace(/^_+/, "").toLowerCase();
    }
    function isMessageTextFieldName(key) {
      const normalized = normalizedFieldName(key);
      if (MESSAGE_TEXT_FIELDS.has(normalized)) {
        return true;
      }
      if (normalized.includes("context")) {
        return false;
      }
      return normalized.endsWith("text") || normalized.endsWith("body") || normalized.endsWith("caption") || normalized.endsWith("description");
    }
    function safeGetField(value, key) {
      try {
        return value && value[key];
      } catch {
        return void 0;
      }
    }
    function objectFieldNames(value) {
      if (!value || typeof value !== "object") {
        return [];
      }
      const names = new Set(Object.keys(value));
      const proto = Object.getPrototypeOf(value);
      if (proto && proto !== Object.prototype) {
        for (const name of Object.getOwnPropertyNames(proto)) {
          if (name !== "constructor") {
            names.add(name);
          }
        }
      }
      return Array.from(names).filter((name) => !MESSAGE_TEXT_EXCLUDED_FIELDS.has(name));
    }
    const serializedObjectViewCache = /* @__PURE__ */ new WeakMap();
    function serializedObjectView(value) {
      if (!value || typeof value !== "object") {
        return null;
      }
      if (serializedObjectViewCache.has(value)) {
        return serializedObjectViewCache.get(value);
      }
      for (const method of ["serialize", "toJSON", "toObject"]) {
        if (typeof value[method] !== "function") {
          continue;
        }
        try {
          const converted = value[method]();
          if (converted && converted !== value && typeof converted === "object") {
            serializedObjectViewCache.set(value, converted);
            return converted;
          }
        } catch {
        }
      }
      for (const key of ["attributes", "_attributes"]) {
        const converted = safeGetField(value, key);
        if (converted && converted !== value && typeof converted === "object") {
          serializedObjectViewCache.set(value, converted);
          return converted;
        }
      }
      serializedObjectViewCache.set(value, null);
      return null;
    }
    function textFromKnownFields(value, depth = 0, seen = /* @__PURE__ */ new WeakSet()) {
      if (!value || typeof value !== "object" || depth > 6 || bytesToUint8Array(value)) {
        return "";
      }
      if (seen.has(value)) {
        return "";
      }
      seen.add(value);
      const converted = serializedObjectView(value);
      if (converted) {
        const convertedText = textFromKnownFields(converted, depth + 1, seen);
        if (convertedText) {
          return convertedText;
        }
      }
      const names = objectFieldNames(value);
      for (const key of names) {
        if (!isMessageTextFieldName(key)) {
          continue;
        }
        const fieldValue = safeGetField(value, key);
        const fieldText = text(fieldValue);
        if (fieldText) {
          return fieldText;
        }
        const nestedText = textFromKnownFields(fieldValue, depth + 1, seen);
        if (nestedText) {
          return nestedText;
        }
      }
      for (const key of MESSAGE_NESTED_FIELDS) {
        const nested = safeGetField(value, key);
        const nestedText = textFromKnownFields(nested, depth + 1, seen);
        if (nestedText) {
          return nestedText;
        }
      }
      return "";
    }
    function isLID(jid) {
      return typeof jid === "string" && jid.endsWith("@lid");
    }
    function isPN(jid) {
      return typeof jid === "string" && (jid.endsWith("@s.whatsapp.net") || jid.endsWith("@c.us"));
    }
    function phoneNumberToPNJID(value) {
      const jid = jidToString(value);
      if (isPN(jid)) {
        return jid;
      }
      const digits = text(value).replace(/\D/g, "");
      return digits ? `${digits}@s.whatsapp.net` : "";
    }
    function pnFromContact(row) {
      const phone = phoneNumberToPNJID(row.phoneNumber);
      if (phone) {
        return phone;
      }
      const id = jidToString(row.id);
      return isPN(id) ? id : "";
    }
    function contactTextFromSource(source, names) {
      if (!source || typeof source !== "object") {
        return "";
      }
      return text(firstWhatsAppFieldValue(source, names));
    }
    function contactTextFromSources(sources, names) {
      for (const source of sources) {
        const value = contactTextFromSource(source, names);
        if (value) {
          return value;
        }
      }
      return "";
    }
    function contactNestedSources(row) {
      const sources = [];
      if (row && typeof row === "object") {
        sources.push(row);
        for (const key of ["contact", "contactObj", "senderObj", "authorObj", "profile", "chat"]) {
          const nested = firstWhatsAppFieldValue(row, [key]);
          if (nested && typeof nested === "object") {
            sources.push(nested);
          }
        }
      }
      return sources;
    }
    function contactFirstName(row) {
      return contactTextFromSources(contactNestedSources(row), ["firstName", "shortName", "formattedShortName"]);
    }
    function contactFullName(row) {
      return contactTextFromSources(contactNestedSources(row), ["fullName", "name", "displayName", "formattedName", "formattedTitle", "title"]);
    }
    function contactPushName(row) {
      return contactTextFromSources(contactNestedSources(row), ["pushName", "pushname", "notifyName", "notify", "senderName", "formattedUser"]);
    }
    function contactBusinessName(row) {
      return contactTextFromSources(contactNestedSources(row), ["businessName", "verifiedName", "verifiedNameForDisplay", "displayBusinessName"]);
    }
    function mapContact(row) {
      const id = jidToString(row.id);
      const pn = pnFromContact(row);
      const lid = isLID(id) ? id : jidToString(row.lid);
      const jid = pn || id || lid;
      if (!jid && !lid) {
        return null;
      }
      return compactObject({
        jid,
        lid,
        firstName: contactFirstName(row),
        fullName: contactFullName(row),
        pushName: contactPushName(row),
        businessName: contactBusinessName(row),
        phoneNumber: pn
      });
    }
    function mapContactFromChat(row) {
      const jid = jidToString(firstWhatsAppFieldValue(row, ["id", "wid"]));
      const lid = jidToString(firstWhatsAppFieldValue(row, ["accountLid", "lid"]));
      if (!jid && !lid) {
        return null;
      }
      if (jid.endsWith("@g.us")) {
        return null;
      }
      return compactObject({
        jid: jid || lid,
        lid,
        firstName: contactFirstName(row),
        fullName: contactFullName(row),
        pushName: contactPushName(row),
        businessName: contactBusinessName(row)
      });
    }
    function mapChat(row) {
      const jid = jidToString(firstWhatsAppFieldValue(row, ["id", "wid"]));
      if (!jid) {
        return null;
      }
      return compactObject({
        jid,
        lid: jidToString(firstWhatsAppFieldValue(row, ["accountLid", "lid"])),
        name: text(firstWhatsAppFieldValue(row, ["name", "formattedTitle", "displayName"])),
        isGroup: jid.endsWith("@g.us"),
        archived: Boolean(firstWhatsAppFieldValue(row, ["archive", "archived"])),
        pinned: Boolean(firstWhatsAppFieldValue(row, ["pin", "pinned"])),
        mutedUntilMs: timestampMs(firstWhatsAppFieldValue(row, ["muteExpiration", "muteExpirationMs"])),
        lastMessageTimestampMs: timestampMs(firstWhatsAppFieldValue(row, ["t", "timestamp", "lastReceivedKeyTimestamp"]))
      });
    }
    function mapContactFromMessage(message) {
      const jid = text(message?.senderJid);
      const pushName = text(message?.senderName);
      if (!jid || !pushName) {
        return null;
      }
      return compactObject({
        jid,
        pushName
      });
    }
    function mergeContacts(...contactLists) {
      const byJid = /* @__PURE__ */ new Map();
      for (const contact of contactLists.flat()) {
        const jid = text(contact?.jid);
        if (!jid) {
          continue;
        }
        const existing = byJid.get(jid);
        if (!existing) {
          byJid.set(jid, contact);
          continue;
        }
        byJid.set(jid, {
          ...existing,
          ...contact,
          jid,
          lid: text(contact.lid) || text(existing.lid),
          firstName: text(existing.firstName) || text(contact.firstName),
          fullName: text(existing.fullName) || text(contact.fullName),
          pushName: text(existing.pushName) || text(contact.pushName),
          businessName: text(existing.businessName) || text(contact.businessName),
          phoneNumber: text(existing.phoneNumber) || text(contact.phoneNumber)
        });
      }
      return Array.from(byJid.values());
    }
    function mapPrivacyToken(row) {
      const token = row.tcToken || row.token;
      const tokenBytes = token && typeof token === "object" && "_data" in token ? token._data : token;
      const encoded = bytesToBase64(tokenBytes);
      if (!encoded) {
        return null;
      }
      const userJid = jidToString(row.accountLid || row.id || row.userJid);
      if (!userJid) {
        return null;
      }
      const tokenTimestampMS = timestampMs(row.tcTokenTimestamp || row.timestampMs || row.timestamp);
      return compactObject({
        userJid,
        token: encoded,
        timestampS: Math.floor(tokenTimestampMS / 1e3),
        senderTimestampS: row.tcTokenSenderTimestamp ? Math.floor(timestampMs(row.tcTokenSenderTimestamp) / 1e3) : void 0
      });
    }
    function deserializeMessageRow(row, serializer) {
      const fromRow = serializer && serializer.messageFromDbRow;
      if (typeof fromRow !== "function") {
        return null;
      }
      try {
        const message = fromRow(row);
        if (message && message.msgRowOpaqueData && typeof serializer.movFieldFromOpaqueDataBackToMsg === "function") {
          try {
            serializer.movFieldFromOpaqueDataBackToMsg(message);
          } catch {
          }
        }
        return message;
      } catch {
        return null;
      }
    }
    function serializedMessageKey(message) {
      if (!message || typeof message !== "object") {
        return {};
      }
      const converted = serializedObjectView(message);
      return message.key || message.id || message.msgKey || converted?.key || converted?.id || converted?.msgKey || {};
    }
    function unwrapMessagePayload(value) {
      if (!value || typeof value !== "object") {
        return value;
      }
      const wrappers = [
        "ephemeralMessage",
        "viewOnceMessage",
        "viewOnceMessageV2",
        "viewOnceMessageV2Extension",
        "documentWithCaptionMessage",
        "editedMessage"
      ];
      for (const key of wrappers) {
        const nested = value[key];
        if (nested && typeof nested === "object") {
          if (nested.message) {
            return unwrapMessagePayload(nested.message);
          }
          return unwrapMessagePayload(nested);
        }
      }
      if (value.protocolMessage && value.protocolMessage.editedMessage) {
        return unwrapMessagePayload(value.protocolMessage.editedMessage);
      }
      return value;
    }
    function textFromMessagePayload(value, depth = 0) {
      if (!value || depth > 5) {
        return "";
      }
      const direct = text(value);
      if (direct) {
        return direct;
      }
      if (typeof value !== "object") {
        return "";
      }
      const payload = unwrapMessagePayload(value);
      if (payload !== value) {
        const nestedText = textFromMessagePayload(payload, depth + 1);
        if (nestedText) {
          return nestedText;
        }
      }
      const knownText = firstText(
        payload.conversation,
        payload.text,
        payload.caption,
        payload.body,
        payload.content,
        payload.contentText,
        payload.footerText,
        payload.title,
        payload.description,
        payload.name,
        payload.selectedDisplayText
      );
      if (knownText) {
        return knownText;
      }
      const knownFieldText = textFromKnownFields(payload);
      if (knownFieldText) {
        return knownFieldText;
      }
      const nestedCandidates = [
        payload.extendedTextMessage,
        payload.imageMessage,
        payload.videoMessage,
        payload.documentMessage,
        payload.audioMessage,
        payload.stickerMessage,
        payload.buttonsMessage,
        payload.listMessage,
        payload.pollCreationMessage,
        payload.pollCreationMessageV2,
        payload.pollCreationMessageV3,
        payload.eventMessage,
        payload.locationMessage,
        payload.liveLocationMessage,
        payload.contactMessage,
        payload.contactsArrayMessage,
        payload.productMessage,
        payload.orderMessage,
        payload.templateMessage && payload.templateMessage.hydratedTemplate,
        payload.templateMessage && payload.templateMessage.hydratedFourRowTemplate,
        payload.templateMessage && payload.templateMessage.fourRowTemplate,
        payload.interactiveMessage,
        payload.interactiveMessage && payload.interactiveMessage.body,
        payload.interactiveMessage && payload.interactiveMessage.footer,
        payload.interactiveMessage && payload.interactiveMessage.header
      ];
      for (const candidate of nestedCandidates) {
        const nestedText = textFromMessagePayload(candidate, depth + 1);
        if (nestedText) {
          return nestedText;
        }
      }
      return "";
    }
    function textFromSerializedMessage(message) {
      if (!message || typeof message !== "object") {
        return "";
      }
      return firstText(message.body, message.caption, message.text, message.messageText) || textFromMessagePayload(message.message || message.msg || message._message) || textFromMessagePayload(message.msgOpaqueData || message.opaqueData || message.data || message.payload) || textFromKnownFields(message);
    }
    function messageGetterValue(getters, name, message) {
      const getter = getters && getters[name];
      if (typeof getter !== "function" || !message) {
        return void 0;
      }
      try {
        return getter(message);
      } catch {
        return void 0;
      }
    }
    function messageGetterText(getters, message, names) {
      for (const name of names) {
        const value = messageGetterValue(getters, name, message);
        const candidate = text(value);
        if (candidate) {
          return candidate;
        }
      }
      return "";
    }
    function mediaMessageFromPayload(value) {
      const payload = unwrapMessagePayload(value);
      if (!payload || typeof payload !== "object") {
        return {};
      }
      return payload.imageMessage || payload.videoMessage || payload.documentMessage || payload.documentWithCaptionMessage && payload.documentWithCaptionMessage.message && payload.documentWithCaptionMessage.message.documentMessage || payload.audioMessage || payload.stickerMessage || {};
    }
    const WEB_MESSAGE_TYPE_TO_STORED_TYPE = Object.freeze({
      audio: "AudioMessage",
      audiomessage: "AudioMessage",
      chat: "Conversation",
      contactmessage: "ContactMessage",
      contactsarraymessage: "ContactsArrayMessage",
      conversation: "Conversation",
      document: "DocumentMessage",
      documentmessage: "DocumentMessage",
      extendedtextmessage: "ExtendedTextMessage",
      image: "ImageMessage",
      imagemessage: "ImageMessage",
      live_location: "LiveLocationMessage",
      livelocationmessage: "LiveLocationMessage",
      location: "LocationMessage",
      locationmessage: "LocationMessage",
      multi_vcard: "ContactsArrayMessage",
      ptt: "AudioMessage",
      protocolmessage: "ProtocolMessage",
      reaction: "ReactionMessage",
      reactionmessage: "ReactionMessage",
      revoked: "ProtocolMessage",
      sticker: "StickerMessage",
      stickermessage: "StickerMessage",
      vcard: "ContactMessage",
      video: "VideoMessage",
      videomessage: "VideoMessage"
    });
    const EXPORTABLE_MESSAGE_TYPES = /* @__PURE__ */ new Set([
      "AudioMessage",
      "ContactMessage",
      "ContactsArrayMessage",
      "Conversation",
      "DocumentMessage",
      "ExtendedTextMessage",
      "ImageMessage",
      "LiveLocationMessage",
      "LocationMessage",
      "ReactionMessage",
      "StickerMessage",
      "VideoMessage"
    ]);
    function hasObjectKeys(value) {
      return value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length > 0;
    }
    function lowerCamelMessageKey(messageType) {
      const value = text(messageType);
      return value ? value.charAt(0).toLowerCase() + value.slice(1) : "";
    }
    function storedMessageTypeFromWebType(rawType, hasContextInfo = false) {
      const value = text(rawType);
      if (!value) {
        return hasContextInfo ? "ExtendedTextMessage" : "Conversation";
      }
      const lower = value.toLowerCase();
      const mapped = WEB_MESSAGE_TYPE_TO_STORED_TYPE[lower] || value;
      if (mapped === "Conversation" && hasContextInfo) {
        return "ExtendedTextMessage";
      }
      return mapped;
    }
    function isFilteredHistoryChatJID(jid) {
      const value = text(jid).toLowerCase();
      return value === "0@s.whatsapp.net" || value === "status@broadcast";
    }
    function isNonZeroMessageStubType(...values) {
      const value = firstContentValue(...values);
      if (value === void 0) {
        return false;
      }
      const numeric = Number(value);
      if (Number.isFinite(numeric)) {
        return numeric !== 0;
      }
      return Boolean(text(value));
    }
    function firstObjectFieldValue(value, names) {
      const sources = [value];
      const converted = serializedObjectView(value);
      if (converted && converted !== value) {
        sources.push(converted);
      }
      for (const source of sources) {
        for (const name of names) {
          const field = safeGetField(source, name);
          if (field !== void 0 && field !== null && field !== "") {
            return field;
          }
        }
      }
      return void 0;
    }
    function fieldNameAliases(names) {
      const aliases = [];
      for (const name of names) {
        if (!name) {
          continue;
        }
        aliases.push(name, `__x_${name}`, `_${name}`);
        if (name.length <= 3) {
          aliases.push(name.toUpperCase());
        }
        if (name.charAt(0) === name.charAt(0).toLowerCase()) {
          aliases.push(name.charAt(0).toUpperCase() + name.slice(1));
        }
      }
      return aliases;
    }
    function firstWhatsAppFieldValue(value, names) {
      return firstObjectFieldValue(value, fieldNameAliases(names));
    }
    function mediaDataFromSerializedMessage(message) {
      return firstWhatsAppFieldValue(message, ["mediaData"]);
    }
    function firstMessageValue(row, serializedMessage, mediaData, names) {
      const mediaObject = firstWhatsAppFieldValue(serializedMessage, ["mediaObject"]);
      return firstContentValue(
        firstWhatsAppFieldValue(row, names),
        firstWhatsAppFieldValue(serializedMessage, names),
        firstWhatsAppFieldValue(mediaData, names),
        firstWhatsAppFieldValue(mediaObject, names)
      );
    }
    function collectionModels(collection) {
      if (!collection) {
        return [];
      }
      for (const method of ["getModelsArray", "toArray"]) {
        if (typeof collection[method] !== "function") {
          continue;
        }
        try {
          const models = collection[method]();
          if (Array.isArray(models)) {
            return models.filter((item) => item && typeof item === "object");
          }
        } catch {
        }
      }
      for (const key of ["models", "_models"]) {
        const models = safeGetField(collection, key);
        if (Array.isArray(models)) {
          return models.filter((item) => item && typeof item === "object");
        }
        if (models && typeof models === "object") {
          return Object.values(models).filter((item) => item && typeof item === "object");
        }
      }
      return [];
    }
    function readStoreChatModels(limit) {
      const collections = getWaModule("WAWebCollections");
      const sources = [
        collections?.Chat,
        collections?.ChatCollection,
        globalThis.Store?.Chat
      ];
      const byJid = /* @__PURE__ */ new Map();
      for (const source of sources) {
        for (const chat of collectionModels(source)) {
          const mapped = mapChat(chat);
          const jid = text(mapped?.jid);
          if (!jid || byJid.has(jid)) {
            continue;
          }
          byJid.set(jid, chat);
        }
      }
      const chats = Array.from(byJid.values());
      chats.sort((left, right) => timestampMs(firstWhatsAppFieldValue(right, ["t", "timestamp"])) - timestampMs(firstWhatsAppFieldValue(left, ["t", "timestamp"])));
      return chats.slice(0, Number.isFinite(limit) ? Math.max(0, limit) : chats.length);
    }
    function readLatestStoreMessageModels(chatModels, messageGetters, totalLimit) {
      const models = [];
      const chats = Array.isArray(chatModels) ? chatModels : [];
      const seenChats = /* @__PURE__ */ new Set();
      for (const chat of chats) {
        if (models.length >= totalLimit) {
          break;
        }
        const mappedChat = mapChat(chat);
        const chatKeys = uniqueItems([mappedChat?.jid, mappedChat?.lid].map(text));
        const canonicalChat = chatKeys[0];
        if (!canonicalChat || seenChats.has(canonicalChat)) {
          continue;
        }
        const messageCollection = safeGetField(chat, "msgs");
        const candidates = collectionModels(messageCollection).slice(-5);
        let latest = null;
        for (const model of candidates) {
          const mapped = mapMessage({}, model, messageGetters);
          if (!mapped) {
            continue;
          }
          const belongsToChat = [mapped.chatJid, mapped._sourceFromJid, mapped._sourceToJid].map(text).some((candidate) => chatKeys.includes(candidate));
          if (!belongsToChat) {
            continue;
          }
          if (!latest || timestampMs(mapped.timestampMs) > timestampMs(latest.mapped.timestampMs)) {
            latest = { model, mapped };
          }
        }
        if (latest) {
          seenChats.add(canonicalChat);
          models.push(latest.model);
        }
      }
      return models;
    }
    function jidListFromValue(value) {
      if (!value) {
        return [];
      }
      const values = Array.isArray(value) ? value : typeof value !== "string" && typeof value[Symbol.iterator] === "function" ? Array.from(value) : [value];
      return values.map((item) => jidToString(item?.jid || item?.id || item)).filter(Boolean);
    }
    function uniqueItems(values) {
      return Array.from(new Set(values.filter(Boolean)));
    }
    function quotedMessagePayloadFromWebMessage(quotedMessage, quotedType, messageGetters) {
      if (!quotedMessage) {
        return void 0;
      }
      const quotedText = messageGetterText(messageGetters, quotedMessage, ["getBody", "getCaption"]) || textFromSerializedMessage(quotedMessage) || textFromKnownFields(quotedMessage);
      const storedType = storedMessageTypeFromWebType(quotedType || messageGetterValue(messageGetters, "getType", quotedMessage));
      if (storedType === "Conversation") {
        return quotedText ? { conversation: quotedText } : void 0;
      }
      const key = lowerCamelMessageKey(storedType);
      if (!key) {
        return void 0;
      }
      const content = messageContentForStoredType(storedType, quotedText, {}, void 0, quotedType);
      return { [key]: content && typeof content === "object" ? content : {} };
    }
    function contextInfoFromMessage(row, serializedMessage, messageGetters, chatJid) {
      const quotedMessage = messageGetterValue(messageGetters, "getQuotedMsg", serializedMessage) || firstObjectFieldValue(serializedMessage, ["quotedMsg", "quotedMessage"]) || firstObjectFieldValue(row, ["quotedMsg", "quotedMessage"]);
      const stanzaID = text(firstObjectFieldValue(serializedMessage, ["quotedStanzaID", "quotedStanzaId", "quotedStanzaid"])) || text(firstObjectFieldValue(row, ["quotedStanzaID", "quotedStanzaId", "quotedStanzaid"])) || messageIDToString(messageGetterValue(messageGetters, "getId", quotedMessage));
      const participant = jidToString(messageGetterValue(messageGetters, "getQuotedParticipant", serializedMessage)) || jidToString(firstObjectFieldValue(serializedMessage, ["quotedParticipant", "quotedAuthor", "quotedSender"])) || jidToString(firstObjectFieldValue(row, ["quotedParticipant", "quotedAuthor", "quotedSender"]));
      const remoteJID = jidToString(messageGetterValue(messageGetters, "getQuotedRemoteJid", serializedMessage)) || jidToString(firstObjectFieldValue(serializedMessage, ["quotedRemoteJid", "quotedRemoteJID", "quotedRemote"])) || jidToString(firstObjectFieldValue(row, ["quotedRemoteJid", "quotedRemoteJID", "quotedRemote"]));
      const mentionedJID = uniqueItems([
        ...jidListFromValue(messageGetterValue(messageGetters, "getMentionedJidList", serializedMessage)),
        ...jidListFromValue(firstObjectFieldValue(serializedMessage, ["mentionedJidList", "mentionedJID", "mentions"])),
        ...jidListFromValue(firstObjectFieldValue(row, ["mentionedJidList", "mentionedJID", "mentions"]))
      ]);
      const quotedType = text(messageGetterValue(messageGetters, "getQuotedType", serializedMessage)) || text(firstObjectFieldValue(serializedMessage, ["quotedType"])) || text(firstObjectFieldValue(row, ["quotedType"]));
      const contextInfo = compactObject({
        stanzaID,
        participant,
        remoteJID: stanzaID ? remoteJID || chatJid : "",
        mentionedJID: mentionedJID.length > 0 ? mentionedJID : void 0,
        quotedMessage: quotedMessagePayloadFromWebMessage(quotedMessage, quotedType, messageGetters)
      });
      return hasObjectKeys(contextInfo) ? contextInfo : void 0;
    }
    function messageContentForStoredType(messageType, messageText, mediaContent, contextInfo, rawType) {
      if (messageType === "Conversation") {
        return messageText || void 0;
      }
      if (messageType === "ExtendedTextMessage") {
        const content2 = compactObject({
          text: messageText,
          contextInfo
        });
        return hasObjectKeys(content2) ? content2 : void 0;
      }
      const mediaTypesWithCaption = /* @__PURE__ */ new Set(["DocumentMessage", "ImageMessage", "VideoMessage"]);
      const content = compactObject({
        ...mediaContent,
        caption: mediaTypesWithCaption.has(messageType) ? messageText : void 0,
        PTT: text(rawType).toLowerCase() === "ptt" ? true : void 0,
        contextInfo
      });
      return hasObjectKeys(content) ? content : void 0;
    }
    function messagePayloadForWebMessage(messageType, content) {
      if (messageType === "Conversation") {
        return typeof content === "string" && content ? { conversation: content } : void 0;
      }
      const key = lowerCamelMessageKey(messageType);
      if (!key) {
        return void 0;
      }
      return { [key]: content && typeof content === "object" ? content : {} };
    }
    function webMessageStatusFromAck(ack) {
      const value = Number(ack);
      switch (value) {
        case 1:
          return "PENDING";
        case 2:
          return "SERVER_ACK";
        case 3:
          return "DELIVERY_ACK";
        case 4:
          return "READ";
        case 5:
          return "PLAYED";
        default:
          return void 0;
      }
    }
    function webMessageFromStoredContent({ id, chatJid, senderJid, fromMe, timestampMs: rawTimestampMs, messageType, content, ack }) {
      if (!EXPORTABLE_MESSAGE_TYPES.has(messageType)) {
        return void 0;
      }
      const message = messagePayloadForWebMessage(messageType, content);
      if (!message) {
        return void 0;
      }
      const isGroup = chatJid.endsWith("@g.us");
      const timestampSeconds = Math.floor(timestampMs(rawTimestampMs) / 1e3);
      return compactObject({
        key: compactObject({
          remoteJID: chatJid,
          fromMe,
          ID: id,
          participant: isGroup && senderJid ? senderJid : void 0
        }),
        message,
        messageTimestamp: timestampSeconds > 0 ? timestampSeconds : void 0,
        status: webMessageStatusFromAck(ack),
        participant: isGroup && senderJid ? senderJid : void 0
      });
    }
    function mapMessage(row, serializedMessage = null, messageGetters = null) {
      const key = serializedMessageKey(serializedMessage);
      const getterId = messageGetterValue(messageGetters, "getId", serializedMessage);
      const rowID = firstWhatsAppFieldValue(row, ["id"]);
      const serializedID = firstWhatsAppFieldValue(serializedMessage, ["id"]);
      const mediaData = mediaDataFromSerializedMessage(serializedMessage);
      const id = messageIDToString(rowID) || messageIDToString(firstWhatsAppFieldValue(row, ["messageId"])) || text(firstWhatsAppFieldValue(row, ["externalId"])) || text(firstWhatsAppFieldValue(row, ["internalId"])) || text(key.id) || messageIDToString(serializedID) || messageIDToString(getterId);
      const fromMe = rowID && typeof rowID === "object" && typeof rowID.fromMe === "boolean" ? rowID.fromMe : typeof rowID === "string" ? rowID.startsWith("true_") : typeof key.fromMe === "boolean" ? key.fromMe : Boolean(firstWhatsAppFieldValue(row, ["fromMe"]) || firstWhatsAppFieldValue(serializedMessage, ["fromMe", "isMe"]));
      const sourceFromJid = jidToString(firstWhatsAppFieldValue(row, ["from"])) || jidToString(firstWhatsAppFieldValue(serializedMessage, ["from"]));
      const sourceToJid = jidToString(firstWhatsAppFieldValue(row, ["to"])) || jidToString(firstWhatsAppFieldValue(serializedMessage, ["to"]));
      const chatJid = jidToString(firstWhatsAppFieldValue(row, ["chatId"]) || rowID && rowID.remote) || jidToString(key.remoteJid || key.remote) || jidToString(firstWhatsAppFieldValue(serializedMessage, ["chatId", "remoteJid", "remote"])) || jidToString(messageGetterValue(messageGetters, "getRemote", serializedMessage)) || messageChatJIDFromID(rowID) || messageChatJIDFromID(serializedID) || (fromMe ? sourceToJid || sourceFromJid : sourceFromJid || sourceToJid);
      if (!id || !chatJid || isFilteredHistoryChatJID(chatJid)) {
        return null;
      }
      if (isNonZeroMessageStubType(firstWhatsAppFieldValue(row, ["messageStubType", "stubType"]), firstWhatsAppFieldValue(serializedMessage, ["messageStubType", "stubType"]))) {
        return null;
      }
      const mediaMessage = mediaMessageFromPayload(serializedMessage && (serializedMessage.message || serializedMessage.msg || serializedMessage._message));
      const senderJid = jidToString(
        firstWhatsAppFieldValue(row, ["author", "sender"]) || rowID && rowID.participant || key.participant || firstWhatsAppFieldValue(serializedMessage, ["author", "sender"]) || messageGetterValue(messageGetters, "getSender", serializedMessage) || messageGetterValue(messageGetters, "getAuthor", serializedMessage) || sourceFromJid
      );
      const senderName = firstText(
        contactTextFromSources(contactNestedSources(row), ["senderName", "notifyName", "pushName", "pushname"]),
        contactTextFromSources(contactNestedSources(serializedMessage), ["senderName", "notifyName", "pushName", "pushname"])
      );
      const getterText = messageGetterText(messageGetters, serializedMessage, ["getBody", "getCaption", "getTitle", "getComment", "getPollName", "getEventName", "getEventDescription"]);
      const messageText = firstText(
        firstWhatsAppFieldValue(row, ["body", "caption", "text"]),
        firstWhatsAppFieldValue(serializedMessage, ["body", "caption", "text", "pollName", "eventName", "eventDescription"]),
        getterText
      ) || textFromSerializedMessage(serializedMessage) || textFromKnownFields(row);
      const contextInfo = contextInfoFromMessage(row, serializedMessage, messageGetters, chatJid);
      const rawType = text(firstWhatsAppFieldValue(row, ["type"])) || text(firstWhatsAppFieldValue(serializedMessage, ["type"])) || text(firstWhatsAppFieldValue(mediaData, ["type"])) || text(messageGetterValue(messageGetters, "getType", serializedMessage));
      const messageType = storedMessageTypeFromWebType(rawType, Boolean(contextInfo));
      if (!EXPORTABLE_MESSAGE_TYPES.has(messageType)) {
        return null;
      }
      const ack = firstContentValue(firstWhatsAppFieldValue(row, ["ack"]), firstWhatsAppFieldValue(serializedMessage, ["ack"]), messageGetterValue(messageGetters, "getAck", serializedMessage));
      const mediaContent = compactObject({
        body: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["body"]), mediaMessage.body),
        text: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["text"]), mediaMessage.text),
        caption: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["caption"]), mediaMessage.caption),
        URL: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["deprecatedMms3Url", "url", "URL"]), messageGetterValue(messageGetters, "getDeprecatedMms3Url", serializedMessage), mediaMessage.url),
        mimetype: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["mimetype", "mimeType"]), messageGetterValue(messageGetters, "getMimetype", serializedMessage), mediaMessage.mimetype),
        fileSHA256: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["fileSHA256", "fileSha256", "filehash", "fileHash"]), messageGetterValue(messageGetters, "getFilehash", serializedMessage), mediaMessage.fileSHA256, mediaMessage.fileSha256, mediaMessage.filehash),
        fileEncSHA256: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["fileEncSHA256", "fileEncSha256", "fileEncHash", "encFilehash", "encFileHash"]), mediaMessage.fileEncSHA256, mediaMessage.fileEncSha256, mediaMessage.fileEncHash),
        mediaKey: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["mediaKey"]), mediaMessage.mediaKey),
        fileLength: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["fileLength", "size"]), mediaMessage.fileLength, mediaMessage.size),
        seconds: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["seconds", "duration"]), mediaMessage.seconds, mediaMessage.duration),
        directPath: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["directPath"]), mediaMessage.directPath),
        mediaKeyTimestamp: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["mediaKeyTimestamp", "mediaKeyTimestampMs"]), mediaMessage.mediaKeyTimestamp),
        thumbnail: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["thumbnail"]), mediaMessage.thumbnail),
        JPEGThumbnail: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["JPEGThumbnail", "jpegThumbnail"]), mediaMessage.JPEGThumbnail, mediaMessage.jpegThumbnail),
        thumbnailDirectPath: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["thumbnailDirectPath"]), mediaMessage.thumbnailDirectPath),
        thumbnailSHA256: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["thumbnailSHA256", "thumbnailSha256"]), mediaMessage.thumbnailSHA256, mediaMessage.thumbnailSha256),
        thumbnailEncSHA256: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["thumbnailEncSHA256", "thumbnailEncSha256"]), mediaMessage.thumbnailEncSHA256, mediaMessage.thumbnailEncSha256),
        thumbnailHeight: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["thumbnailHeight"]), mediaMessage.thumbnailHeight),
        thumbnailWidth: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["thumbnailWidth"]), mediaMessage.thumbnailWidth),
        pngThumbnail: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["pngThumbnail"]), mediaMessage.pngThumbnail),
        waveform: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["waveform"]), mediaMessage.waveform),
        title: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["title"]), mediaMessage.title),
        fileName: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["fileName", "filename"]), mediaMessage.fileName),
        pageCount: firstContentValue(firstMessageValue(row, serializedMessage, mediaData, ["pageCount"]), mediaMessage.pageCount)
      });
      const content = messageContentForStoredType(messageType, messageText, mediaContent, contextInfo, rawType);
      const messageTimestampMs = timestampMs(firstDefined2(
        firstWhatsAppFieldValue(row, ["t", "timestamp", "messageTimestamp"]),
        messageGetterValue(messageGetters, "getT", serializedMessage),
        firstWhatsAppFieldValue(serializedMessage, ["t", "timestamp", "messageTimestamp"])
      ));
      const webMessage = webMessageFromStoredContent({
        id,
        chatJid,
        senderJid,
        fromMe,
        timestampMs: messageTimestampMs,
        messageType,
        content,
        ack
      });
      if (!webMessage) {
        return null;
      }
      return compactObject({
        id,
        chatJid,
        senderJid,
        senderName,
        fromMe,
        timestampMs: messageTimestampMs,
        type: messageType,
        text: messageText,
        content,
        webMessage,
        _sourceFromJid: sourceFromJid,
        _sourceToJid: sourceToJid
      });
    }
    function selectRecentHistoryChats(chats, limit) {
      const out = Array.isArray(chats) ? [...chats] : [];
      out.sort((left, right) => {
        const leftTimestamp = timestampMs(left?.lastMessageTimestampMs);
        const rightTimestamp = timestampMs(right?.lastMessageTimestampMs);
        if (leftTimestamp === rightTimestamp) {
          return text(left?.jid).localeCompare(text(right?.jid));
        }
        return rightTimestamp - leftTimestamp;
      });
      return out.slice(0, Math.max(0, limit));
    }
    function mergeChatsByJid(...chatLists) {
      const byJid = /* @__PURE__ */ new Map();
      for (const chat of chatLists.flat()) {
        const jid = text(chat?.jid);
        if (!jid) {
          continue;
        }
        const existing = byJid.get(jid);
        if (!existing) {
          byJid.set(jid, chat);
          continue;
        }
        byJid.set(jid, {
          ...existing,
          ...chat,
          name: text(chat.name) || text(existing.name),
          lid: text(chat.lid) || text(existing.lid),
          lastMessageTimestampMs: Math.max(timestampMs(existing.lastMessageTimestampMs), timestampMs(chat.lastMessageTimestampMs))
        });
      }
      return Array.from(byJid.values());
    }
    function messageTimestampIndexName(store) {
      const names = Array.from(store.indexNames || []);
      const preferred = ["t", "timestamp", "timestampMs", "messageTimestamp", "rowId"];
      for (const preferredName of preferred) {
        const found = names.find((name) => name.toLowerCase() === preferredName.toLowerCase());
        if (found) {
          return found;
        }
      }
      return "";
    }
    function messageRowSummary(row) {
      const rowID = firstWhatsAppFieldValue(row, ["id"]);
      const sourceFromJid = jidToString(firstWhatsAppFieldValue(row, ["from"]));
      const sourceToJid = jidToString(firstWhatsAppFieldValue(row, ["to"]));
      const fromMe = rowID && typeof rowID === "object" && typeof rowID.fromMe === "boolean" ? rowID.fromMe : typeof rowID === "string" ? rowID.startsWith("true_") : Boolean(firstWhatsAppFieldValue(row, ["fromMe"]));
      const chatJid = jidToString(firstWhatsAppFieldValue(row, ["chatId"]) || rowID && rowID.remote) || messageChatJIDFromID(rowID) || (fromMe ? sourceToJid || sourceFromJid : sourceFromJid || sourceToJid);
      const id = messageIDToString(rowID) || messageIDToString(firstWhatsAppFieldValue(row, ["messageId"])) || text(firstWhatsAppFieldValue(row, ["externalId"])) || text(firstWhatsAppFieldValue(row, ["internalId"]));
      return {
        id,
        chatJids: uniqueItems([chatJid, sourceFromJid, sourceToJid].map(text)),
        timestampMs: timestampMs(firstDefined2(firstWhatsAppFieldValue(row, ["t", "timestamp", "messageTimestamp"])))
      };
    }
    async function readRecentMessageRowsForChats(dbName, storeName, chats, limit, maxScanned) {
      const targetChatByAlias = /* @__PURE__ */ new Map();
      const canonicalChats = /* @__PURE__ */ new Set();
      for (const chat of Array.isArray(chats) ? chats : []) {
        const jid = text(chat?.jid);
        const lid = text(chat?.lid);
        const canonical = jid || lid;
        if (!canonical) {
          continue;
        }
        canonicalChats.add(canonical);
        for (const alias of [jid, lid].filter(Boolean)) {
          targetChatByAlias.set(alias, canonical);
        }
      }
      const wantedCount = Math.max(0, Math.min(Math.floor(limit || 0), canonicalChats.size || Math.floor(limit || 0)));
      if (wantedCount === 0) {
        return [];
      }
      if (targetChatByAlias.size === 0) {
        return readStore(dbName, storeName, wantedCount, "prev");
      }
      const db = await openDatabase(dbName);
      try {
        if (!Array.from(db.objectStoreNames || []).includes(storeName)) {
          return [];
        }
        const tx = db.transaction(storeName, "readonly");
        const store = tx.objectStore(storeName);
        const indexName = messageTimestampIndexName(store);
        const source = indexName ? store.index(indexName) : store;
        const orderedByTimestamp = Boolean(indexName);
        const selectedByChat = /* @__PURE__ */ new Map();
        let scanned = 0;
        await new Promise((resolve, reject) => {
          const request = source.openCursor(null, "prev");
          request.onsuccess = () => {
            const cursor = request.result;
            if (!cursor || scanned >= maxScanned || orderedByTimestamp && selectedByChat.size >= wantedCount) {
              resolve();
              return;
            }
            scanned += 1;
            const summary = messageRowSummary(cursor.value);
            const chatAlias = summary.chatJids.find((candidate) => targetChatByAlias.has(candidate));
            const canonicalChat = chatAlias ? targetChatByAlias.get(chatAlias) : "";
            if (canonicalChat && summary.id) {
              const existing = selectedByChat.get(canonicalChat);
              if (!existing || summary.timestampMs > existing.summary.timestampMs) {
                selectedByChat.set(canonicalChat, { row: cursor.value, summary });
              }
            }
            cursor.continue();
          };
          request.onerror = () => reject(request.error || new Error(`Falha ao ler ${storeName}`));
        });
        const selectedRows = Array.from(selectedByChat.values()).sort((left, right) => timestampMs(right.summary.timestampMs) - timestampMs(left.summary.timestampMs)).slice(0, wantedCount).map((item) => item.row);
        if (selectedRows.length === 0) {
          return readStore(dbName, storeName, wantedCount, "prev");
        }
        return selectedRows;
      } finally {
        db.close();
      }
    }
    function limitHistoryAnchors2(history, limit) {
      const rawChats = Array.isArray(history?.chats) ? history.chats : [];
      const rawMessages = Array.isArray(history?.messages) ? history.messages : [];
      const latestMessageByChat = /* @__PURE__ */ new Map();
      const messagesByChat = /* @__PURE__ */ new Map();
      const seenMessages = /* @__PURE__ */ new Set();
      for (const message of rawMessages) {
        const chatJid = text(message.chatJid);
        const id = text(message.id);
        if (!chatJid || !id) {
          continue;
        }
        const messageKey = `${chatJid}\0${id}`;
        if (seenMessages.has(messageKey)) {
          continue;
        }
        seenMessages.add(messageKey);
        const normalized = { ...message, id, chatJid, timestampMs: timestampMs(message.timestampMs) };
        if (!messagesByChat.has(chatJid)) {
          messagesByChat.set(chatJid, []);
        }
        messagesByChat.get(chatJid).push(normalized);
        const existing = latestMessageByChat.get(chatJid);
        if (!existing || normalized.timestampMs > Number(existing.timestampMs || 0)) {
          latestMessageByChat.set(chatJid, normalized);
        }
      }
      const chatByJid = /* @__PURE__ */ new Map();
      for (const chat of rawChats) {
        const jid = text(chat.jid);
        if (!jid) {
          continue;
        }
        const normalized = {
          ...chat,
          jid,
          lid: text(chat.lid),
          lastMessageTimestampMs: timestampMs(chat.lastMessageTimestampMs)
        };
        const existing = chatByJid.get(jid);
        if (!existing || normalized.lastMessageTimestampMs > timestampMs(existing.lastMessageTimestampMs)) {
          chatByJid.set(jid, normalized);
        }
      }
      const hasChatForMessageJID = (jid) => {
        if (chatByJid.has(jid)) {
          return true;
        }
        for (const chat of chatByJid.values()) {
          if (text(chat?.lid) === jid) {
            return true;
          }
        }
        return false;
      };
      for (const message of latestMessageByChat.values()) {
        if (!hasChatForMessageJID(message.chatJid)) {
          chatByJid.set(message.chatJid, {
            jid: message.chatJid,
            isGroup: message.chatJid.endsWith("@g.us"),
            lastMessageTimestampMs: timestampMs(message.timestampMs)
          });
        }
      }
      const latestMessageForChat = (chat) => {
        let latest = null;
        for (const chatKey of [chat?.jid, chat?.lid].filter(Boolean)) {
          const candidate = latestMessageByChat.get(chatKey);
          if (!candidate) {
            continue;
          }
          if (!latest || Number(candidate.timestampMs || 0) > Number(latest.timestampMs || 0)) {
            latest = candidate;
          }
        }
        return latest;
      };
      const chats = Array.from(chatByJid.values()).filter(
        (chat) => [chat.jid, chat.lid].filter(Boolean).some((chatKey) => messagesByChat.has(chatKey))
      );
      chats.sort((left, right) => {
        const leftMessage = latestMessageForChat(left);
        const rightMessage = latestMessageForChat(right);
        const leftTimestamp = Math.max(timestampMs(left.lastMessageTimestampMs), Number(leftMessage?.timestampMs || 0));
        const rightTimestamp = Math.max(timestampMs(right.lastMessageTimestampMs), Number(rightMessage?.timestampMs || 0));
        return rightTimestamp - leftTimestamp;
      });
      const selectedChats = chats.slice(0, Math.max(0, limit));
      const selectedMessages = [];
      const selectedMessageKeys = /* @__PURE__ */ new Set();
      for (const chat of selectedChats) {
        const message = latestMessageForChat(chat);
        if (!message) {
          continue;
        }
        const messageKey = `${message.chatJid}\0${message.id}`;
        if (!selectedMessageKeys.has(messageKey)) {
          selectedMessageKeys.add(messageKey);
          selectedMessages.push(message);
        }
      }
      selectedMessages.sort((left, right) => Number(right.timestampMs || 0) - Number(left.timestampMs || 0));
      return { chats: selectedChats, messages: selectedMessages };
    }
    async function run() {
      const contactRows = await readStore("model-storage", "contact", LIMITS.contacts);
      const chatRows = await readStore("model-storage", "chat", LIMITS.chats);
      const contactStoreContacts = contactRows.map(mapContact).filter(Boolean);
      const chatContactHints = chatRows.map(mapContactFromChat).filter(Boolean);
      const privacyTokens = chatRows.map(mapPrivacyToken).filter(Boolean);
      const messageSerializer = getWaModule("WAWebDBMessageSerialization");
      const messageGetters = getWaModule("WAWebMsgGetters");
      const storeChatModels = readStoreChatModels(LIMITS.historyChats);
      const storeChatContactHints = storeChatModels.map(mapContactFromChat).filter(Boolean);
      const dbChats = chatRows.map(mapChat).filter(Boolean);
      const storeChats = storeChatModels.map(mapChat).filter(Boolean);
      const chats = mergeChatsByJid(dbChats, storeChats);
      const recentChats = selectRecentHistoryChats(chats, LIMITS.historyChats);
      const messageRows = await readRecentMessageRowsForChats(
        "model-storage",
        "message",
        recentChats,
        LIMITS.messages,
        LIMITS.messageScan
      );
      let serializedMessageRows = 0;
      let serializedMessageRowsWithText = 0;
      const storeMessageModels = readLatestStoreMessageModels(storeChatModels, messageGetters, LIMITS.messages);
      const messageByChat = /* @__PURE__ */ new Map();
      const addMessage = (mapped) => {
        const chatJid = text(mapped?.chatJid);
        const id = text(mapped?.id);
        if (!chatJid || !id) {
          return;
        }
        const existing = messageByChat.get(chatJid);
        const mappedTimestamp = timestampMs(mapped.timestampMs);
        const existingTimestamp = timestampMs(existing?.timestampMs);
        if (!existing || mappedTimestamp > existingTimestamp || mappedTimestamp === existingTimestamp && !text(existing.text) && text(mapped.text)) {
          messageByChat.set(chatJid, mapped);
        }
      };
      for (const model of storeMessageModels) {
        addMessage(mapMessage({}, model, messageGetters));
      }
      for (const row of messageRows) {
        const serializedMessage = deserializeMessageRow(row, messageSerializer);
        if (serializedMessage) {
          serializedMessageRows += 1;
        }
        const mapped = mapMessage(row, serializedMessage, messageGetters);
        if (serializedMessage && text(mapped?.text)) {
          serializedMessageRowsWithText += 1;
        }
        addMessage(mapped);
      }
      const messages = Array.from(messageByChat.values()).sort((left, right) => timestampMs(right.timestampMs) - timestampMs(left.timestampMs));
      const messageContactHints = messages.map(mapContactFromMessage).filter(Boolean);
      const contacts = mergeContacts(contactStoreContacts, chatContactHints, storeChatContactHints, messageContactHints);
      const history = limitHistoryAnchors2({ chats: recentChats.length > 0 ? recentChats : chats, messages }, LIMITS.historyChats);
      return {
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        source: "whatsapp-web-sidecar-v1",
        url: location.href,
        contacts,
        privacyTokens,
        history: {
          chats: history.chats,
          messages: history.messages
        },
        counts: {
          mode: "history",
          contactRows: contactRows.length,
          chatRows: chatRows.length,
          storeChatModels: storeChatModels.length,
          messageRows: messageRows.length,
          storeMessageModels: storeMessageModels.length,
          messageRowsSerialized: serializedMessageRows,
          messageRowsSerializedWithText: serializedMessageRowsWithText,
          messageRowsDecrypted: 0,
          messageRowsDecryptedWithText: 0,
          contactStoreContacts: contactStoreContacts.length,
          chatContactHints: chatContactHints.length,
          storeChatContactHints: storeChatContactHints.length,
          messageContactHints: messageContactHints.length,
          contacts: contacts.length,
          contactsWithFullName: contacts.filter((contact) => text(contact.fullName)).length,
          contactsWithPushName: contacts.filter((contact) => text(contact.pushName)).length,
          privacyTokens: privacyTokens.length,
          historyChatsRaw: chats.length,
          historyMessagesRaw: messages.length,
          historyChats: history.chats.length,
          historyMessages: history.messages.length,
          historyMessagesWithText: history.messages.filter((message) => text(message.text)).length
        }
      };
    }
    return run().then((dump) => ({ dump })).catch((error) => ({ error: error.message || "Falha ao capturar hist\xF3rico" }));
  }

  // src/background/page-scripts/extract-session.ts
  function extractWhatsAppWebMainDump(options = {}) {
    function bytesToB64(bytes) {
      if (!bytes) {
        return null;
      }
      let u;
      if (bytes instanceof Uint8Array) {
        u = bytes;
      } else if (bytes instanceof ArrayBuffer) {
        u = new Uint8Array(bytes);
      } else if (typeof bytes === "string") {
        u = Uint8Array.from(bytes, (c) => c.charCodeAt(0));
      } else {
        return null;
      }
      const chunks = [];
      const step = 32768;
      for (let i = 0; i < u.length; i += step) {
        chunks.push(String.fromCharCode.apply(null, u.subarray(i, i + step)));
      }
      return btoa(chunks.join(""));
    }
    function bufWrap(bytes) {
      const data = bytesToB64(bytes);
      return data == null ? null : { type: "Buffer", data };
    }
    function deepBufWrap(value) {
      if (value == null) {
        return value;
      }
      if (value instanceof Uint8Array || value instanceof ArrayBuffer) {
        return bufWrap(value);
      }
      if (Array.isArray(value)) {
        return value.map(deepBufWrap);
      }
      if (typeof value === "object") {
        const out = {};
        for (const key of Object.keys(value)) {
          if (key !== "$$unknownFieldCount") {
            out[key] = deepBufWrap(value[key]);
          }
        }
        return out;
      }
      return value;
    }
    function openDatabase(name) {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open(name);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error(`Falha ao abrir ${name}`));
        request.onblocked = () => reject(new Error(`Abertura bloqueada: ${name}`));
      });
    }
    function getAll(db, storeName) {
      return new Promise((resolve, reject) => {
        if (!Array.from(db.objectStoreNames || []).includes(storeName)) {
          resolve([]);
          return;
        }
        const tx = db.transaction(storeName, "readonly");
        const request = tx.objectStore(storeName).getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error || new Error(`Falha ao ler ${storeName}`));
      });
    }
    async function decryptRegMaterial(value) {
      if (!value || !value.encKey || !value.value) {
        return null;
      }
      const counter = new Uint8Array(16);
      const cipher = value.value instanceof Uint8Array ? value.value : new Uint8Array(value.value);
      const plain = await crypto.subtle.decrypt({ name: "AES-CTR", length: 128, counter }, value.encKey, cipher);
      return new Uint8Array(plain);
    }
    function getWaModule(name) {
      try {
        if (typeof globalThis.require === "function") {
          return globalThis.require(name);
        }
      } catch {
      }
      try {
        if (typeof __d === "function") {
          let captured;
          const sentinel = `__waDumpProbe_${Math.random().toString(36).slice(2)}`;
          __d(sentinel, [name], function(_target, _namespace, _require, moduleRequire) {
            captured = moduleRequire(name);
          });
          if (!captured && typeof __d.require === "function") {
            captured = __d.require(name);
          }
          if (captured) {
            return captured;
          }
        }
      } catch {
      }
      return null;
    }
    async function getNoiseInfoViaInternalModule() {
      const infoStore = getWaModule("WAWebUserPrefsInfoStore");
      if (!infoStore || !infoStore.waNoiseInfo || typeof infoStore.waNoiseInfo.get !== "function") {
        return null;
      }
      try {
        const decrypted = await infoStore.waNoiseInfo.get();
        if (!decrypted || !decrypted.staticKeyPair) {
          return null;
        }
        return {
          pubKey: new Uint8Array(decrypted.staticKeyPair.pubKey),
          privKey: new Uint8Array(decrypted.staticKeyPair.privKey)
        };
      } catch (error) {
        console.warn("[wa-web-dump] internal noise lookup failed", error);
        return null;
      }
    }
    async function getNoiseInfoFallback() {
      const saltJson = localStorage.getItem("WAWebEncKeySalt");
      const noiseJson = localStorage.getItem("WANoiseInfo");
      const ivJson = localStorage.getItem("WANoiseInfoIv");
      if (!saltJson || !noiseJson || !ivJson) {
        return null;
      }
      const saltBytes = Uint8Array.from(atob(JSON.parse(saltJson)), (c) => c.charCodeAt(0));
      const noiseObj = JSON.parse(noiseJson);
      const ivs = JSON.parse(ivJson).map((value) => Uint8Array.from(atob(value), (c) => c.charCodeAt(0)));
      const encPub = Uint8Array.from(atob(noiseObj.pubKey), (c) => c.charCodeAt(0));
      const encPriv = Uint8Array.from(atob(noiseObj.privKey), (c) => c.charCodeAt(0));
      const db = await openDatabase("wawc_db_enc");
      const baseRows = await getAll(db, "keys");
      db.close();
      for (const row of baseRows || []) {
        try {
          const aesKey = await crypto.subtle.deriveKey(
            { name: "HKDF", hash: "SHA-256", salt: saltBytes, info: new Uint8Array(1) },
            row.key,
            { name: "AES-CBC", length: 128 },
            false,
            ["decrypt"]
          );
          const pub = await crypto.subtle.decrypt({ name: "AES-CBC", iv: ivs[1] }, aesKey, encPub);
          const priv = await crypto.subtle.decrypt({ name: "AES-CBC", iv: ivs[2] }, aesKey, encPriv);
          return { pubKey: new Uint8Array(pub), privKey: new Uint8Array(priv) };
        } catch {
        }
      }
      return null;
    }
    async function getNoiseKey() {
      return await getNoiseInfoViaInternalModule() || await getNoiseInfoFallback();
    }
    function parseAddress(addr) {
      const raw = String(addr || "");
      const dot = raw.lastIndexOf(".");
      const head = dot >= 0 ? raw.slice(0, dot) : raw;
      const parsedDevice = dot >= 0 ? Number(raw.slice(dot + 1)) : 0;
      const jid = head.includes("@") ? head : `${head}@s.whatsapp.net`;
      return { jid, device: Number.isFinite(parsedDevice) ? parsedDevice : 0 };
    }
    function parseSenderKeyName(name) {
      const raw = String(name || "");
      const sep = raw.indexOf("::");
      if (sep < 0) {
        return null;
      }
      const groupId = raw.slice(0, sep);
      const senderPart = raw.slice(sep + 2);
      const parsed = parseAddress(senderPart);
      return { groupId, senderJid: parsed.jid, senderDevice: parsed.device };
    }
    async function getModelTable(schemaModuleName, tableGetterName) {
      const mod = getWaModule(schemaModuleName);
      const getter = mod && mod[tableGetterName];
      if (typeof getter !== "function") {
        return [];
      }
      try {
        const rows = await getter().all();
        return Array.isArray(rows) ? rows : [];
      } catch (error) {
        console.warn(`[wa-web-dump] ${schemaModuleName}.${tableGetterName}().all() failed`, error);
        return [];
      }
    }
    function toUint8(value) {
      if (value == null) {
        return null;
      }
      if (value instanceof Uint8Array) {
        return value;
      }
      if (value instanceof ArrayBuffer) {
        return new Uint8Array(value);
      }
      if (typeof value === "object" && value.buffer instanceof ArrayBuffer) {
        return new Uint8Array(value.buffer, value.byteOffset || 0, value.byteLength || value.buffer.byteLength);
      }
      if (typeof value === "string") {
        return Uint8Array.from(value, (c) => c.charCodeAt(0));
      }
      return null;
    }
    function timestampMs(value) {
      if (!Number.isFinite(value) || value <= 0) {
        return 0;
      }
      return value < 1e11 ? Math.floor(value * 1e3) : Math.floor(value);
    }
    function normalizeWhatsAppUserJID(value) {
      const trimmed = String(value || "").trim();
      const at = trimmed.lastIndexOf("@");
      if (at < 0) {
        return trimmed;
      }
      const server = trimmed.slice(at + 1);
      if (server === "c.us") {
        return `${trimmed.slice(0, at)}@s.whatsapp.net`;
      }
      return trimmed;
    }
    function jidToString(value) {
      if (!value) {
        return "";
      }
      if (typeof value === "string") {
        return normalizeWhatsAppUserJID(value);
      }
      if (typeof value === "object") {
        if (typeof value._serialized === "string") {
          return normalizeWhatsAppUserJID(value._serialized);
        }
        if (typeof value.user === "string" && typeof value.server === "string") {
          return normalizeWhatsAppUserJID(`${value.user}@${value.server}`);
        }
      }
      return "";
    }
    function widToJid(wid) {
      if (!wid || typeof wid !== "string") {
        return null;
      }
      const at = wid.lastIndexOf("@");
      const head = at >= 0 ? wid.slice(0, at) : wid;
      const server = at >= 0 ? wid.slice(at + 1) : "s.whatsapp.net";
      const colon = head.indexOf(":");
      const userAndAgent = colon >= 0 ? head.slice(0, colon) : head;
      const device = colon >= 0 ? Number(head.slice(colon + 1)) : 0;
      const dot = userAndAgent.indexOf(".");
      const user = dot >= 0 ? userAndAgent.slice(0, dot) : userAndAgent;
      return `${user}:${Number.isFinite(device) ? device : 0}@${server}`;
    }
    function readJSONLocalStorage(key) {
      try {
        return JSON.parse(localStorage.getItem(key) || "null");
      } catch {
        return null;
      }
    }
    function downloadInPage(filename, data) {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename;
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    }
    async function run() {
      const includeContacts = options.includeContacts !== false;
      const signalDB = await openDatabase("signal-storage");
      const [meta, identity, prekey, signedPrekey, session, senderkey] = await Promise.all([
        getAll(signalDB, "signal-meta-store"),
        getAll(signalDB, "identity-store"),
        getAll(signalDB, "prekey-store"),
        getAll(signalDB, "signed-prekey-store"),
        getAll(signalDB, "session-store"),
        getAll(signalDB, "senderkey-store")
      ]);
      signalDB.close();
      const metaMap = {};
      for (const row of meta) {
        metaMap[row.key] = row.value;
      }
      const staticPub = await decryptRegMaterial(metaMap.signal_static_pubkey);
      const staticPriv = await decryptRegMaterial(metaMap.signal_static_privkey);
      const noise = await getNoiseKey();
      const advSignedIdentity = metaMap.adv_signed_identity ? deepBufWrap(metaMap.adv_signed_identity) : null;
      const [
        syncKeysRows,
        collectionVersionRows,
        syncActionsRows,
        contactRows,
        tcTokenRows,
        userPrefsRows
      ] = await Promise.all([
        getModelTable("WAWebSchemaSyncKeys", "getSyncKeysTable"),
        getModelTable("WAWebSchemaCollectionVersion", "getCollectionVersionTable"),
        getModelTable("WAWebSchemaSyncActions", "getSyncActionsTable"),
        includeContacts ? getModelTable("WAWebSchemaContact_DO_NOT_USE_DIRECTLY", "getContactTable") : Promise.resolve([]),
        getModelTable("WAWebSchemaOrphanTcToken", "getOrphanTcTokenTable"),
        getModelTable("WAWebSchemaUserPrefs", "getUserPrefsTable")
      ]);
      const userPrefs = {};
      for (const row of userPrefsRows) {
        if (row && row.key) {
          userPrefs[String(row.key)] = row.value;
        }
      }
      if (userPrefsRows.length === 0) {
        try {
          const modelDB = await openDatabase("model-storage");
          const rows = await getAll(modelDB, "user-prefs");
          for (const row of rows) {
            if (row && row.key) {
              userPrefs[String(row.key)] = row.value;
            }
          }
          modelDB.close();
        } catch (error) {
          console.warn("[wa-web-dump] user-prefs raw fallback failed", error);
        }
      }
      let advSecretKey = null;
      try {
        const value = await (getWaModule("WAWebUserPrefsMultiDevice") || {}).getADVSecretKey?.();
        if (typeof value === "string") {
          advSecretKey = Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
        } else if (value) {
          advSecretKey = toUint8(value);
        }
      } catch {
      }
      const appStateSyncKeys = syncKeysRows.map((row) => {
        const keyId = toUint8(row.keyId);
        const keyData = toUint8(row.keyData);
        if (!keyId || !keyData) {
          return null;
        }
        return {
          keyId: bufWrap(keyId),
          keyData: bufWrap(keyData),
          timestamp: row.timestamp || 0,
          ...row.fingerprint ? { fingerprint: row.fingerprint } : {},
          ...row.keyEpoch !== void 0 ? { keyEpoch: row.keyEpoch } : {}
        };
      }).filter(Boolean);
      const indexValueByCollection = /* @__PURE__ */ new Map();
      for (const action of syncActionsRows) {
        const indexMac = toUint8(action.indexMac);
        const valueMac = toUint8(action.valueMac);
        if (!action.collection || !indexMac || !valueMac) {
          continue;
        }
        const map = indexValueByCollection.get(action.collection) || {};
        map[bytesToB64(indexMac)] = bufWrap(valueMac);
        indexValueByCollection.set(action.collection, map);
      }
      const appStateVersions = collectionVersionRows.map((row) => {
        const hash = toUint8(row.ltHash);
        if (!row.collection || !hash) {
          return null;
        }
        return {
          collection: row.collection,
          version: row.version || 0,
          hash: bufWrap(hash),
          indexValueMap: indexValueByCollection.get(row.collection) || {}
        };
      }).filter(Boolean);
      const contacts = contactRows.map((row) => {
        const jid = jidToString(row.id);
        if (!jid) {
          return null;
        }
        const lid = jidToString(row.lid || row.accountLid);
        return {
          jid,
          ...lid ? { lid } : {},
          ...row.name ? { displayName: String(row.name) } : {},
          ...row.pushname ? { pushName: String(row.pushname) } : {},
          ...row.verifiedName ? { verifiedName: String(row.verifiedName) } : {},
          ...row.phoneNumber ? { phoneNumber: jidToString(row.phoneNumber) || String(row.phoneNumber) } : {}
        };
      }).filter(Boolean);
      const privacyTokens = tcTokenRows.map((row) => {
        const token = toUint8(row.tcToken);
        const jid = jidToString(row.chatId || row.id);
        if (!jid || !token) {
          return null;
        }
        return {
          jid,
          token: bufWrap(token),
          timestampMs: timestampMs(row.tcTokenTimestamp || row.timestampMs || row.timestamp)
        };
      }).filter(Boolean);
      const signedPreKeyRow = signedPrekey[signedPrekey.length - 1] || null;
      const dump = {
        device: {
          registrationId: metaMap.signal_reg_id || null,
          noiseKey: noise ? { pubKey: bufWrap(noise.pubKey), privKey: bufWrap(noise.privKey) } : null,
          identityKey: staticPub && staticPriv ? { pubKey: bufWrap(staticPub), privKey: bufWrap(staticPriv) } : null,
          signedPreKey: signedPreKeyRow ? {
            keyId: signedPreKeyRow.keyId,
            keyPair: {
              pubKey: bufWrap(signedPreKeyRow.keyPair.pubKey),
              privKey: bufWrap(signedPreKeyRow.keyPair.privKey)
            },
            signature: bufWrap(signedPreKeyRow.signature)
          } : null,
          advSecretKey: advSecretKey ? bufWrap(advSecretKey) : bufWrap(new Uint8Array(0)),
          account: advSignedIdentity,
          meJid: widToJid(readJSONLocalStorage("last-wid-md")),
          meLid: widToJid(readJSONLocalStorage("WALid")),
          pushName: readJSONLocalStorage("me-display-name") || "",
          platform: "web"
        },
        preKeys: prekey.map((row) => ({
          keyId: row.keyId,
          keyPair: { pubKey: bufWrap(row.keyPair.pubKey), privKey: bufWrap(row.keyPair.privKey) },
          uploaded: Boolean(row.uploaded)
        })),
        identities: identity.map((row) => {
          const parsed = parseAddress(row.identifier);
          return { jid: parsed.jid, device: parsed.device, identityKey: bufWrap(row.identityKey) };
        }),
        sessions: session.map((row) => {
          const parsed = parseAddress(row.address);
          return { jid: parsed.jid, device: parsed.device, session: deepBufWrap(row.session) };
        }),
        senderKeys: senderkey.map((row) => {
          const parsed = parseSenderKeyName(row.senderKeyName);
          if (!parsed) {
            return null;
          }
          return {
            groupId: parsed.groupId,
            senderJid: parsed.senderJid,
            senderDevice: parsed.senderDevice,
            record: deepBufWrap(row.senderKey)
          };
        }).filter(Boolean),
        appStateSyncKeys,
        appStateVersions,
        privacyTokens,
        contacts
      };
      const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
      const filename = `wa-web-dump-${timestamp}.json`;
      if (options.download !== false) {
        downloadInPage(filename, dump);
      }
      window.__waWebDumpResult = dump;
      const result = {
        filename,
        meJid: dump.device.meJid,
        meLid: dump.device.meLid,
        hasNoiseKey: Boolean(dump.device.noiseKey),
        hasIdentityKey: Boolean(dump.device.identityKey),
        hasSignedPreKey: Boolean(dump.device.signedPreKey),
        preKeys: dump.preKeys.length,
        identities: dump.identities.length,
        sessions: dump.sessions.length,
        senderKeys: dump.senderKeys.length,
        appStateSyncKeys: dump.appStateSyncKeys.length,
        appStateVersions: dump.appStateVersions.length,
        privacyTokens: dump.privacyTokens.length,
        contacts: dump.contacts.length
      };
      if (options.includeDump) {
        result.dump = dump;
      }
      return result;
    }
    return run().then((dump) => ({ dump })).catch((error) => ({ error: error.message || "Falha ao capturar sess\xE3o" }));
  }

  // src/background/page-scripts/storage-inventory.ts
  function extractWhatsAppWebStorageInventory() {
    const MAX_SAMPLES = 3;
    const MAX_DEPTH = 2;
    const knownDatabaseNames = ["signal-storage", "model-storage", "wawc_db_enc"];
    function redactText(value) {
      return String(value || "").replace(/[0-9]{4,}/g, (match) => `<digits:${match.length}>`).replace(/[A-Za-z0-9+/=_-]{80,}/g, (match) => `<encoded:${match.length}>`);
    }
    function isBytes(value) {
      return value instanceof ArrayBuffer || ArrayBuffer.isView(value);
    }
    function byteLength(value) {
      if (value instanceof ArrayBuffer) {
        return value.byteLength;
      }
      if (ArrayBuffer.isView(value)) {
        return value.byteLength;
      }
      return 0;
    }
    function describeValue(value, depth = 0) {
      if (value == null || typeof value === "number" || typeof value === "boolean") {
        return { type: String(value), value };
      }
      if (typeof value === "string") {
        return { type: "string", length: value.length, preview: redactText(value.slice(0, 120)) };
      }
      if (value instanceof Date) {
        return { type: "Date", value: value.toISOString() };
      }
      if (isBytes(value)) {
        return { type: value.constructor ? value.constructor.name : "Bytes", byteLength: byteLength(value) };
      }
      if (Array.isArray(value)) {
        return {
          type: "Array",
          length: value.length,
          items: depth >= MAX_DEPTH ? [] : value.slice(0, MAX_SAMPLES).map((item) => describeValue(item, depth + 1))
        };
      }
      if (typeof value === "object") {
        const keys = Object.keys(value);
        const fields = {};
        if (depth < MAX_DEPTH) {
          for (const key of keys.slice(0, 20)) {
            fields[key] = describeValue(value[key], depth + 1);
          }
        }
        return { type: value.constructor ? value.constructor.name : "Object", keys: keys.slice(0, 40), fields };
      }
      return { type: typeof value };
    }
    function openDatabase(name) {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open(name);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error(`Falha ao abrir ${name}`));
        request.onblocked = () => reject(new Error(`Abertura bloqueada: ${name}`));
      });
    }
    function requestToPromise(request) {
      return new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error("IndexedDB request failed"));
      });
    }
    async function listDatabaseNames() {
      const discovered = new Set(knownDatabaseNames);
      if (typeof indexedDB.databases === "function") {
        const databases = await indexedDB.databases();
        for (const db of databases || []) {
          if (db && db.name) {
            discovered.add(db.name);
          }
        }
      }
      return Array.from(discovered).sort();
    }
    async function inspectStore(db, storeName) {
      const tx = db.transaction(storeName, "readonly");
      const store = tx.objectStore(storeName);
      const count = await requestToPromise(store.count()).catch(() => null);
      const samples = [];
      await new Promise((resolve, reject) => {
        const request = store.openCursor();
        request.onsuccess = () => {
          const cursor = request.result;
          if (!cursor || samples.length >= MAX_SAMPLES) {
            resolve();
            return;
          }
          samples.push({
            key: describeValue(cursor.key),
            primaryKey: describeValue(cursor.primaryKey),
            value: describeValue(cursor.value)
          });
          cursor.continue();
        };
        request.onerror = () => reject(request.error || new Error(`Falha ao ler ${storeName}`));
      }).catch((error) => {
        samples.push({ error: error.message || String(error) });
      });
      return {
        name: storeName,
        count,
        keyPath: store.keyPath || null,
        autoIncrement: Boolean(store.autoIncrement),
        indexes: Array.from(store.indexNames || []),
        samples
      };
    }
    async function inspectDatabase(name) {
      const db = await openDatabase(name);
      try {
        const stores = [];
        for (const storeName of Array.from(db.objectStoreNames || [])) {
          stores.push(await inspectStore(db, storeName));
        }
        return { name, version: db.version, stores };
      } finally {
        db.close();
      }
    }
    async function run() {
      const localStorageKeys = Object.keys(localStorage || {}).sort();
      const indexedDBResults = [];
      for (const name of await listDatabaseNames()) {
        try {
          indexedDBResults.push(await inspectDatabase(name));
        } catch (error) {
          indexedDBResults.push({ name, error: error.message || String(error) });
        }
      }
      return {
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: location.href,
        localStorageKeys: localStorageKeys.map(redactText),
        indexedDB: indexedDBResults
      };
    }
    return run().then((inventory) => ({ inventory })).catch((error) => ({ error: error.message || "Falha ao diagnosticar armazenamento" }));
  }

  // src/background/tab.ts
  async function executeScriptInPage(tabId, func, args = []) {
    try {
      return await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func,
        args
      });
    } catch (error) {
      if (!String(error && error.message || "").includes("world")) {
        throw error;
      }
      return await chrome.scripting.executeScript({
        target: { tabId },
        func,
        args
      });
    }
  }
  async function isWhatsAppWebLoggedInTab(tabId) {
    const [result] = await executeScriptInPage(tabId, (selectors) => {
      const isVisibleElement = (element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
      };
      return selectors.some((selector) => {
        try {
          const element = document.querySelector(selector);
          return Boolean(element && isVisibleElement(element));
        } catch {
          return false;
        }
      });
    }, [WHATSAPP_LOGGED_IN_SELECTORS]);
    return result?.result === true;
  }
  async function extractInventoryFromTab(tabId) {
    const [result] = await executeScriptInPage(tabId, extractWhatsAppWebStorageInventory);
    if (!result || !result.result) {
      throw new Error("N\xE3o foi poss\xEDvel diagnosticar o armazenamento");
    }
    if (result.result.error) {
      throw new Error(result.result.error);
    }
    return result.result.inventory;
  }
  async function extractSidecarFromTab(tabId, options = {}) {
    const [result] = await executeScriptInPage(tabId, extractWhatsAppWebSidecarDump, [{
      historyChatLimit: IMPORT_HISTORY_CHAT_LIMIT,
      ...options
    }]);
    if (!result || !result.result) {
      throw new Error("N\xE3o foi poss\xEDvel capturar o hist\xF3rico");
    }
    if (result.result.error) {
      throw new Error(result.result.error);
    }
    return result.result.dump;
  }
  async function extractMainDumpFromTab(tabId, options = {}) {
    const [result] = await executeScriptInPage(tabId, extractWhatsAppWebMainDump, [options]);
    if (!result || !result.result) {
      throw new Error("N\xE3o foi poss\xEDvel capturar a sess\xE3o");
    }
    if (result.result.error) {
      throw new Error(result.result.error);
    }
    if (options.includeDump && result.result.dump && result.result.dump.dump) {
      return result.result.dump.dump;
    }
    return result.result.dump;
  }
  async function clearWhatsAppWebLocalSessionFromTab(tab) {
    if (!tab || !tab.id) {
      throw new Error("Aba do WhatsApp Web indispon\xEDvel para limpeza local");
    }
    const [result] = await executeScriptInPage(tab.id, clearWhatsAppWebLocalSessionData);
    if (!result || !result.result) {
      throw new Error("N\xE3o foi poss\xEDvel limpar os dados locais do WhatsApp Web");
    }
    if (result.result.error) {
      throw new Error(result.result.error);
    }
    return result.result.summary || { method: "page" };
  }

  // src/background/index.ts
  importScripts("vendor/wa-store-migrate.bundle.js");
  var runningImports = /* @__PURE__ */ new Set();
  var SESSION_STABILITY_POLLS = 2;
  var SESSION_STABILITY_MAX_ATTEMPTS = 8;
  var SESSION_STABILITY_INTERVAL_MS = 1200;
  function postToPort(port, payload) {
    try {
      port.postMessage(payload);
    } catch (error) {
      console.warn("Failed to post import status", error);
    }
  }
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function scheduleWhatsAppTabReload(tabId) {
    if (!tabId) {
      return;
    }
    setTimeout(() => {
      chrome.tabs.reload(tabId, { bypassCache: true }).catch((error) => {
        console.warn("Failed to reload WhatsApp Web after local cleanup", error);
      });
    }, 1e3);
  }
  function historyImportSummary(result, payload) {
    return `hist\xF3rico repassado: contatos=${result.contacts || payload.contacts.length}, perfis=${result.contactProfiles || 0}, store=${result.storeContacts || 0}, chats=${result.historyChats || payload.history.chats?.length || 0}, mensagens=${result.historyMsgs || payload.history.messages?.length || 0}, mappings=${result.lidMappings || 0}`;
  }
  function importSummaryText(result, importPayload, includeHistory, cleanup, connectResult, historyImport) {
    const imported = result.imported || {};
    const cleanupWarning = cleanup && cleanup.error ? "; limpeza local falhou: " + cleanup.error : "";
    const connectNote = connectResult?.queued ? "; conex\xE3o em andamento" : "";
    const historyNote = !includeHistory ? "; hist\xF3rico ignorado" : historyImport?.error ? "; hist\xF3rico n\xE3o repassado: " + historyImport.error : historyImport?.message ? "; " + historyImport.message : "; hist\xF3rico n\xE3o repassado";
    return "Importa\xE7\xE3o conclu\xEDda" + historyNote + cleanupWarning + connectNote + ". jid=" + (result.jid || importPayload.device?.meJid || "n/a") + ", contatos=" + (imported.contacts || 0) + ", chunks=" + (result.chunks || 0);
  }
  function sessionDumpCompleteness(dump) {
    const device = dump?.device || {};
    return {
      meJid: String(device.meJid || ""),
      hasNoiseKey: Boolean(device.noiseKey),
      hasIdentityKey: Boolean(device.identityKey),
      hasAccount: Boolean(device.account),
      complete: Boolean(device.meJid && device.noiseKey && device.identityKey && device.account)
    };
  }
  function incompleteSessionReason(state) {
    const missing = [];
    if (!state.meJid) missing.push("jid");
    if (!state.hasNoiseKey) missing.push("noiseKey");
    if (!state.hasIdentityKey) missing.push("identityKey");
    if (!state.hasAccount) missing.push("account");
    return missing.length ? `Sess\xE3o incompleta: ${missing.join(", ")}` : "Sess\xE3o ainda n\xE3o estabilizou";
  }
  function userFacingErrorMessage(error) {
    const message = String(error?.message || error || "");
    if (message.includes("noiseKey")) {
      return "A sess\xE3o ainda n\xE3o liberou a noiseKey. Aguarde o WhatsApp Web terminar de carregar e tente novamente.";
    }
    if (message.includes("identityKey") || message.includes("account") || message.includes("Sess\xE3o incompleta")) {
      return message;
    }
    if (message.includes("A inst\xE2ncia precisa estar desconectada")) {
      return message;
    }
    if (message.includes("Failed to fetch") || message.includes("NetworkError")) {
      return "Falha de rede ao conectar. Confira o nome da assinatura, a conex\xE3o e as permiss\xF5es da extens\xE3o.";
    }
    if (message.includes("Falha ao enviar chunk")) {
      return `${message}. A importa\xE7\xE3o foi interrompida antes da finaliza\xE7\xE3o.`;
    }
    if (message.includes("API n\xE3o retornou jobId")) {
      return "A API iniciou a importa\xE7\xE3o sem retornar jobId. Verifique o contrato do endpoint /start.";
    }
    if (message.includes("N\xE3o foi poss\xEDvel capturar a sess\xE3o")) {
      return "N\xE3o foi poss\xEDvel capturar a sess\xE3o. Recarregue o WhatsApp Web, aguarde conectar e tente novamente.";
    }
    if (message.includes("N\xE3o foi poss\xEDvel capturar o hist\xF3rico")) {
      return "N\xE3o foi poss\xEDvel capturar dados auxiliares/hist\xF3rico do WhatsApp Web.";
    }
    return message || "Falha ao executar comando";
  }
  async function waitForStableMainDump(tabId, onStatus) {
    let stableJid = "";
    let stableCount = 0;
    let lastState = null;
    for (let attempt = 1; attempt <= SESSION_STABILITY_MAX_ATTEMPTS; attempt += 1) {
      const dump = await extractMainDumpFromTab(tabId, { download: false, includeDump: true, includeContacts: false });
      const state = sessionDumpCompleteness(dump);
      lastState = state;
      if (state.complete && state.meJid === stableJid) {
        stableCount += 1;
      } else {
        stableJid = state.meJid;
        stableCount = state.complete ? 1 : 0;
      }
      if (state.complete && stableCount >= SESSION_STABILITY_POLLS) {
        return dump;
      }
      onStatus?.({
        message: `${incompleteSessionReason(state)}. Tentando novamente ${attempt}/${SESSION_STABILITY_MAX_ATTEMPTS}...`
      });
      await sleep(SESSION_STABILITY_INTERVAL_MS);
    }
    throw new Error(`${incompleteSessionReason(lastState || {})}. Aguarde o WhatsApp Web terminar de carregar e tente novamente.`);
  }
  function buildHistoryOnlyPayloadFromDump(dump) {
    const contacts = Array.isArray(dump.contacts) ? dump.contacts.map(normalizeContactForWhatsmeow).filter(Boolean) : [];
    return {
      contacts,
      history: normalizeHistoryJIDsWithContactLIDMap(dump.history || { chats: [], messages: [] }, contacts)
    };
  }
  async function captureAndUploadHistory(tabId, serverUrl, token, onStatus) {
    onStatus({ message: "Capturando hist\xF3rico..." });
    const dump = await extractSidecarFromTab(tabId);
    const payload = buildHistoryOnlyPayloadFromDump(dump);
    onStatus({ message: "Repassando hist\xF3rico..." });
    const result = await uploadHistoryOnlyPayload(serverUrl, token, payload);
    const message = historyImportSummary(result, payload);
    onStatus({ message: "Sess\xE3o importada; " + message + ".", kind: "ok" });
    return { result, payload, message };
  }
  async function runFloatingImport(tab, options, onStatus) {
    if (!tab || !tab.id || !String(tab.url || "").startsWith(WHATSAPP_WEB_URL_PREFIX)) {
      throw new Error("Abra uma aba do WhatsApp Web conectado");
    }
    if (runningImports.has(tab.id)) {
      throw new Error("J\xE1 existe uma importa\xE7\xE3o em andamento nesta aba");
    }
    if (!await isWhatsAppWebLoggedInTab(tab.id)) {
      throw new Error("Entre no WhatsApp Web antes de importar a sess\xE3o");
    }
    runningImports.add(tab.id);
    try {
      const client = String(options?.client || "").trim();
      const token = String(options?.token || "").trim();
      const includeHistory = options?.includeHistory === void 0 ? DEFAULT_INCLUDE_HISTORY : options?.includeHistory === true;
      const disconnectLocal = options?.disconnectLocal !== false;
      if (!client || !token) {
        throw new Error("Informe o nome da assinatura e o token");
      }
      const serverUrl = normalizeBaseUrl(client);
      await chrome.storage.local.set({
        [STORAGE_KEYS.serverUrl]: client,
        [STORAGE_KEYS.instanceToken]: token,
        [STORAGE_KEYS.includeHistory]: includeHistory,
        [STORAGE_KEYS.disconnectLocal]: disconnectLocal
      });
      onStatus({ message: "Validando inst\xE2ncia..." });
      await verifyInstanceForImport(serverUrl, token);
      onStatus({ message: "Capturando e validando sess\xE3o..." });
      const mainDump = await waitForStableMainDump(tab.id, onStatus);
      if (!mainDump || !mainDump.device) {
        throw new Error("Captura da sess\xE3o n\xE3o retornou dados");
      }
      onStatus({ message: "Convertendo para whatsmeow..." });
      const converted = buildWhatsmeowPayload(mainDump, null);
      const importPayload = importPayloadForOptions(converted.payload, { includeHistory: false });
      onStatus({ message: "Enviando chunks..." });
      const result = await uploadWhatsmeowPayload(serverUrl, token, importPayload, {
        onProgress: (done, total, section) => {
          onStatus({ message: "Enviando chunks " + done + "/" + total + " (" + section + ")..." });
        }
      });
      let historyImport = null;
      if (includeHistory) {
        try {
          historyImport = await captureAndUploadHistory(tab.id, serverUrl, token, onStatus);
        } catch (historyError) {
          const message = userFacingErrorMessage(historyError);
          historyImport = { error: message };
          console.warn("Optional WhatsApp history import failed after successful session import", historyError);
          onStatus({ message: "Sess\xE3o importada. Hist\xF3rico n\xE3o foi repassado: " + message, kind: "warn" });
        }
      }
      let cleanup = null;
      if (disconnectLocal) {
        onStatus({ message: "Importa\xE7\xE3o conclu\xEDda. Desconectando WhatsApp Web local...", kind: "ok" });
        try {
          cleanup = await clearWhatsAppWebLocalSessionFromTab(tab);
          onStatus({ message: "Aguardando limpeza local..." });
          await sleep(1200);
        } catch (cleanupError) {
          cleanup = { error: cleanupError.message || "Falha ao limpar dados locais do WhatsApp Web" };
          console.warn("WhatsApp Web local cleanup failed after successful import", cleanupError);
        }
      }
      let connectResult = null;
      if (disconnectLocal && !(cleanup && cleanup.error)) {
        if (result.connect_queued === true) {
          connectResult = { queued: true };
          onStatus({ message: "Conex\xE3o da inst\xE2ncia em andamento.", kind: "ok" });
        }
      }
      const kind = historyImport?.error ? "warn" : "ok";
      return {
        message: importSummaryText(result, importPayload, includeHistory, cleanup, connectResult, historyImport),
        result,
        cleanup,
        connect: connectResult,
        history: historyImport,
        includeHistory,
        kind,
        reloadWhatsAppTab: disconnectLocal && !(cleanup && cleanup.error),
        losses: converted.losses
      };
    } finally {
      runningImports.delete(tab.id);
    }
  }
  async function runHistoryOnlyImport(tab, options, onStatus) {
    if (!tab || !tab.id || !String(tab.url || "").startsWith(WHATSAPP_WEB_URL_PREFIX)) {
      throw new Error("Abra uma aba do WhatsApp Web conectado");
    }
    if (!await isWhatsAppWebLoggedInTab(tab.id)) {
      throw new Error("Entre no WhatsApp Web antes de repassar o hist\xF3rico");
    }
    const client = String(options?.client || "").trim();
    const token = String(options?.token || "").trim();
    if (!client || !token) {
      throw new Error("Informe o nome da assinatura e o token");
    }
    const serverUrl = normalizeBaseUrl(client);
    await chrome.storage.local.set({
      [STORAGE_KEYS.serverUrl]: client,
      [STORAGE_KEYS.instanceToken]: token
    });
    onStatus({ message: "Capturando hist\xF3rico..." });
    const dump = await extractSidecarFromTab(tab.id);
    const payload = buildHistoryOnlyPayloadFromDump(dump);
    onStatus({ message: "Repassando hist\xF3rico..." });
    const result = await uploadHistoryOnlyPayload(serverUrl, token, payload);
    return {
      message: "Hist\xF3rico repassado. " + historyImportSummary(result, payload).replace("hist\xF3rico repassado: ", ""),
      result,
      includeHistory: true
    };
  }
  function ensureWhatsAppTab(tab) {
    if (!tab || !tab.id || !String(tab.url || "").startsWith(WHATSAPP_WEB_URL_PREFIX)) {
      throw new Error("Abra uma aba do WhatsApp Web conectado");
    }
  }
  function timestampForFilename() {
    return (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  }
  async function runTechnicalCommand(tab, type, onStatus) {
    ensureWhatsAppTab(tab);
    if (type === BACKGROUND_COMMANDS.diagnose) {
      onStatus({ message: "Diagnosticando armazenamento..." });
      const inventory = await extractInventoryFromTab(tab.id);
      const dbCount = inventory.indexedDB ? inventory.indexedDB.length : 0;
      const storeCount = (inventory.indexedDB || []).reduce((sum, db) => sum + (db.stores ? db.stores.length : 0), 0);
      return {
        message: `Diagn\xF3stico gerado. bancos=${dbCount}, \xE1reas=${storeCount}`,
        download: {
          filename: `whatsapp-web-storage-inventory-${timestampForFilename()}.json`,
          data: inventory
        }
      };
    }
    if (type === BACKGROUND_COMMANDS.dumpHistory) {
      onStatus({ message: "Capturando hist\xF3rico..." });
      const dump = await extractSidecarFromTab(tab.id);
      const messagesWithText = dump.counts?.historyMessagesWithText || 0;
      return {
        message: `Dump gerado. contatos=${dump.contacts.length}, chats=${dump.history.chats.length}, mensagens=${dump.history.messages.length}, com texto=${messagesWithText}, tokens=${dump.privacyTokens.length}`,
        download: {
          filename: `whatsapp-web-sidecar-${timestampForFilename()}.json`,
          data: dump
        }
      };
    }
    if (type === BACKGROUND_COMMANDS.dumpSession) {
      onStatus({ message: "Capturando sess\xE3o..." });
      const dump = await extractMainDumpFromTab(tab.id);
      return {
        message: `Sess\xE3o gerada. arquivo=${dump.filename}, jid=${dump.meJid || "n/a"}, sess\xF5es=${dump.sessions}, preKeys=${dump.preKeys}`
      };
    }
    throw new Error("Comando t\xE9cnico desconhecido");
  }
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== PORT_NAMES.sessionImport) {
      return;
    }
    const tab = port.sender?.tab;
    port.onMessage.addListener((message) => {
      if (!message || !message.type) {
        return;
      }
      const statusCallback = (status) => {
        postToPort(port, { type: PORT_MESSAGE_TYPES.status, ...status });
      };
      const runner = message.type === BACKGROUND_COMMANDS.startImport ? runFloatingImport(tab, message.options || {}, statusCallback) : message.type === BACKGROUND_COMMANDS.importHistoryOnly ? runHistoryOnlyImport(tab, message.options || {}, statusCallback) : runTechnicalCommand(tab, message.type, statusCallback);
      runner.then((payload) => {
        postToPort(port, { type: PORT_MESSAGE_TYPES.done, kind: payload.kind || "ok", message: payload.message, payload });
        if (payload.reloadWhatsAppTab) {
          scheduleWhatsAppTabReload(tab?.id);
        }
      }).catch((error) => {
        console.warn("Session connector command failed", error);
        postToPort(port, { type: PORT_MESSAGE_TYPES.error, kind: "error", message: userFacingErrorMessage(error) });
      });
    });
  });
  async function openPanelInTab(tab, source = "action") {
    if (!isWhatsAppWebTab(tab)) {
      return false;
    }
    const message = { type: CONTENT_MESSAGE_TYPES.openPanel, source };
    try {
      await chrome.tabs.sendMessage(tab.id, message);
      return true;
    } catch {
    }
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["autofill.js"] });
      await chrome.tabs.sendMessage(tab.id, message);
      return true;
    } catch (error) {
      console.warn("Failed to open floating panel", error);
      return false;
    }
  }
  function optionalBoolean(value) {
    if (value === true || value === "true" || value === "1" || value === 1) {
      return true;
    }
    if (value === false || value === "false" || value === "0" || value === 0) {
      return false;
    }
    return void 0;
  }
  function bridgeImportRequestFromMessage(message) {
    const includeHistory = optionalBoolean(message.includeHistory);
    const hideHistoryOption = optionalBoolean(message.hideHistoryOption);
    const lockHistoryOption = optionalBoolean(message.lockHistoryOption);
    const hideClientField = optionalBoolean(message.hideClientField);
    const hideTokenField = optionalBoolean(message.hideTokenField);
    const lockClientField = optionalBoolean(message.lockClientField);
    const lockTokenField = optionalBoolean(message.lockTokenField);
    const request = {
      id: `bridge-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      createdAt: Date.now(),
      client: String(message.client || "").trim(),
      token: String(message.token || "").trim()
    };
    if (includeHistory !== void 0) {
      request.includeHistory = includeHistory;
    }
    if (hideHistoryOption !== void 0) {
      request.hideHistoryOption = hideHistoryOption;
    }
    if (lockHistoryOption !== void 0) {
      request.lockHistoryOption = lockHistoryOption;
    }
    if (hideClientField !== void 0) {
      request.hideClientField = hideClientField;
    }
    if (hideTokenField !== void 0) {
      request.hideTokenField = hideTokenField;
    }
    if (lockClientField !== void 0) {
      request.lockClientField = lockClientField;
    }
    if (lockTokenField !== void 0) {
      request.lockTokenField = lockTokenField;
    }
    if (message.panelLayout === "center" || message.panelLayout === "corner") {
      request.panelLayout = message.panelLayout;
    }
    return request;
  }
  function isWhatsAppWebTab(tab) {
    return Boolean(tab?.id && String(tab.url || tab.pendingUrl || "").startsWith(WHATSAPP_WEB_URL_PREFIX));
  }
  function newestTab(tabs) {
    return [...tabs].sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0] || null;
  }
  async function activeWhatsAppTab(preferredWindowId) {
    const tabs = await chrome.tabs.query({ url: `${WHATSAPP_WEB_URL_PREFIX}*` });
    const whatsappTabs = tabs.filter(isWhatsAppWebTab);
    if (typeof preferredWindowId === "number") {
      const sameWindowTab = newestTab(whatsappTabs.filter((tab) => tab.windowId === preferredWindowId));
      if (sameWindowTab) {
        return sameWindowTab;
      }
    }
    return newestTab(whatsappTabs);
  }
  async function activateTab(tab) {
    const activeTab = await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId) {
      await chrome.windows.update(tab.windowId, { focused: true }).catch(() => null);
    }
    return activeTab || tab;
  }
  function waitForWhatsAppTabReady(tab, timeoutMs = 15e3) {
    if (!tab?.id) {
      return Promise.resolve(null);
    }
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(null);
      }, timeoutMs);
      const listener = (tabId, changeInfo, updatedTab) => {
        if (tabId !== tab.id || !isWhatsAppWebTab(updatedTab)) {
          return;
        }
        if (changeInfo.status === "complete" || updatedTab.status === "complete") {
          clearTimeout(timeout);
          chrome.tabs.onUpdated.removeListener(listener);
          resolve(updatedTab);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  }
  async function openPanelWhenTabReady(tab, source = "action") {
    if (await openPanelInTab(tab, source)) {
      return true;
    }
    const readyTab = await waitForWhatsAppTabReady(tab);
    return readyTab ? openPanelInTab(readyTab, source) : false;
  }
  async function openFromActionClick(tab) {
    if (isWhatsAppWebTab(tab)) {
      await openPanelWhenTabReady(tab, "action");
      return;
    }
    const existing = await activeWhatsAppTab(tab?.windowId);
    if (existing) {
      await openPanelWhenTabReady(await activateTab(existing), "action");
      return;
    }
    await openPanelWhenTabReady(await chrome.tabs.create({ url: WHATSAPP_WEB_URL_PREFIX, active: true }), "action");
  }
  async function openWhatsAppWithBridgeOptions(message) {
    const request = bridgeImportRequestFromMessage(message);
    const values = {
      [STORAGE_KEYS.bridgeImportRequest]: request,
      [STORAGE_KEYS.serverUrl]: request.client,
      [STORAGE_KEYS.instanceToken]: request.token
    };
    if (request.includeHistory !== void 0) {
      values[STORAGE_KEYS.includeHistory] = request.includeHistory;
    }
    await chrome.storage.local.set(values);
    const existing = await activeWhatsAppTab();
    const tab = existing ? await activateTab(existing) : await chrome.tabs.create({ url: WHATSAPP_WEB_URL_PREFIX, active: true });
    if (existing) {
      await openPanelInTab(tab, "bridge");
    }
    return { ok: true, tabId: tab.id, reused: Boolean(existing) };
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message) {
      return false;
    }
    if (message.type === APP_BRIDGE_MESSAGE_TYPES.ping) {
      sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
      return false;
    }
    if (message.type !== APP_BRIDGE_MESSAGE_TYPES.startImport) {
      return false;
    }
    openWhatsAppWithBridgeOptions(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao abrir WhatsApp Web" }));
    return true;
  });
  chrome.action.onClicked.addListener((tab) => {
    openFromActionClick(tab).catch((error) => {
      console.warn("Failed to open WhatsApp Web from action click", error);
    });
  });
})();
