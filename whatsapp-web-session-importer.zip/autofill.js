(() => {
  // src/customization.ts
  var EXTENSION_CUSTOMIZATION = {
    whatsappWebOrigin: "https://web.whatsapp.com",
    api: {
      clientBaseDomain: "uazapi.com",
      authHeaderName: "token",
      paths: {
        instanceStatus: "/instance/status",
        importWebSessionStart: "/instance/import-web-session/start",
        importWebSessionChunk: "/instance/import-web-session/chunk",
        importWebSessionFinish: "/instance/import-web-session/finish",
        importWebSessionHistory: "/instance/import-web-session/history",
        instanceConnect: "/instance/connect"
      }
    },
    importLimits: {
      chunkItems: 1e3,
      historyChatLimit: 5e3
    },
    importDefaults: {
      // History is useful for continuity, but it depends on WhatsApp Web cache.
      // The service worker imports the session first and treats history failures
      // as warnings so this default cannot break the credential migration.
      includeHistory: true
    },
    appBridge: {
      source: "whatsapp-session-connector",
      matches: [
        "http://localhost/*",
        "http://127.0.0.1/*",
        "https://*.uazapi.com/*"
      ]
    },
    panelText: {
      title: "Migrar sess\xE3o",
      defaultStatus: "WhatsApp Web conectado",
      loggedOutStatus: "Entre no WhatsApp Web para importar",
      clientLabel: "Cliente",
      clientPlaceholder: "cliente",
      tokenLabel: "Token da inst\xE2ncia",
      tokenPlaceholder: "token",
      importButton: "Migrar sess\xE3o",
      diagnoseButton: "Baixar diagn\xF3stico",
      dumpHistoryButton: "Baixar hist\xF3rico",
      historyOnlyButton: "Repassar hist\xF3rico",
      dumpSessionButton: "Baixar sess\xE3o",
      exitDevModeButton: "Sair do modo t\xE9cnico",
      modeDefault: "Modo padr\xE3o",
      modeTechnical: "Modo t\xE9cnico",
      showToken: "Mostrar token",
      hideToken: "Ocultar token",
      closePanel: "Fechar painel",
      openSettings: "Configura\xE7\xF5es",
      closeSettings: "Fechar configura\xE7\xF5es",
      settingsTitle: "Configura\xE7\xF5es",
      autoOpenSetting: "Abrir painel automaticamente",
      autoOpenSettingHint: "Mesmo desativado, links com cliente/token na URL sempre abrem o painel.",
      themeSetting: "Tema do painel",
      themeFollowWhatsApp: "Seguir WhatsApp",
      themeLight: "Claro",
      themeDark: "Escuro",
      saveTokenSetting: "Salvar token neste navegador",
      saveTokenSettingHint: "Desative para preencher o token manualmente a cada importa\xE7\xE3o.",
      includeHistory: "Incluir hist\xF3rico de mensagens (beta)",
      disconnectLocal: "Apagar a sess\xE3o local ap\xF3s importar",
      cleanupNoticeHTML: "<strong>Aten\xE7\xE3o:</strong> esta sess\xE3o ser\xE1 conectada na inst\xE2ncia informada e desconectada deste navegador.",
      keepLocalSessionWarningHTML: "<strong>Risco:</strong> manter a sess\xE3o neste navegador e na inst\xE2ncia ao mesmo tempo roda a mesma conta em dois lugares, o que pode causar desconex\xF5es, perda de mensagens e outros bugs. Use apenas para depura\xE7\xE3o.",
      extensionInvalidated: "A extens\xE3o foi atualizada ou recarregada. Recarregue esta aba do WhatsApp Web e tente novamente."
    }
  };

  // src/shared/config.ts
  var CLIENT_BASE_DOMAIN = EXTENSION_CUSTOMIZATION.api.clientBaseDomain;
  var WHATSAPP_WEB_ORIGIN = EXTENSION_CUSTOMIZATION.whatsappWebOrigin;
  var WHATSAPP_WEB_URL_PREFIX = `${WHATSAPP_WEB_ORIGIN}/`;
  var IMPORT_CHUNK_ITEMS = EXTENSION_CUSTOMIZATION.importLimits.chunkItems;
  var IMPORT_HISTORY_CHAT_LIMIT = EXTENSION_CUSTOMIZATION.importLimits.historyChatLimit;
  var DEFAULT_INCLUDE_HISTORY = EXTENSION_CUSTOMIZATION.importDefaults.includeHistory;
  var API_AUTH_HEADER_NAME = EXTENSION_CUSTOMIZATION.api.authHeaderName;
  var APP_BRIDGE_SOURCE = EXTENSION_CUSTOMIZATION.appBridge.source;
  var APP_BRIDGE_MATCHES = [...EXTENSION_CUSTOMIZATION.appBridge.matches];
  var AUTOFILL_PARAMS = {
    client: "client",
    token: "token"
  };
  var STORAGE_KEYS = {
    serverUrl: "serverUrl",
    instanceToken: "instanceToken",
    includeHistory: "includeHistory",
    disconnectLocal: "disconnectLocal",
    devMode: "devMode",
    userSettings: "userSettings"
  };
  var PORT_NAMES = {
    sessionImport: "session-import"
  };
  var BACKGROUND_COMMANDS = {
    startImport: "START_IMPORT",
    importHistoryOnly: "IMPORT_HISTORY_ONLY",
    diagnose: "DIAGNOSE",
    dumpHistory: "DUMP_HISTORY",
    dumpSession: "DUMP_SESSION"
  };
  var PORT_MESSAGE_TYPES = {
    status: "STATUS",
    done: "DONE",
    error: "ERROR"
  };
  var CONTENT_MESSAGE_TYPES = {
    openPanel: "SESSION_CONNECTOR_OPEN_PANEL"
  };
  var API_PATHS = {
    instanceStatus: EXTENSION_CUSTOMIZATION.api.paths.instanceStatus,
    importWebSessionStart: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionStart,
    importWebSessionChunk: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionChunk,
    importWebSessionFinish: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionFinish,
    importWebSessionHistory: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionHistory,
    instanceConnect: EXTENSION_CUSTOMIZATION.api.paths.instanceConnect
  };
  var WHATSAPP_LOGGED_IN_SELECTORS = [
    "#side",
    "#pane-side",
    '[data-testid="chat-list"]',
    '[data-testid="conversation-panel-wrapper"]',
    '[aria-label="Chat list"]',
    '[aria-label="Lista de conversas"]',
    '[aria-label="Chats"]',
    '[aria-label="Conversas"]'
  ];
  var WHATSAPP_QR_HINTS = [
    "qr code",
    "scan the qr",
    "use whatsapp on your computer",
    "link with phone number",
    "escaneie",
    "c\xF3digo qr",
    "codigo qr",
    "conectar um aparelho",
    "vincular aparelho",
    "vincular com n\xFAmero de telefone",
    "vincular com numero de telefone"
  ];

  // src/shared/url.ts
  function parseAutofillHash(rawUrl) {
    let url;
    try {
      url = new URL(String(rawUrl || ""));
    } catch {
      return null;
    }
    if (url.origin !== WHATSAPP_WEB_ORIGIN) {
      return null;
    }
    const rawHash = url.hash ? url.hash.slice(1) : "";
    if (!rawHash) {
      return null;
    }
    const params = new URLSearchParams(rawHash.startsWith("?") ? rawHash.slice(1) : rawHash);
    const hasClient = params.has(AUTOFILL_PARAMS.client);
    const hasToken = params.has(AUTOFILL_PARAMS.token);
    if (!hasClient && !hasToken) {
      return null;
    }
    return {
      client: String(params.get(AUTOFILL_PARAMS.client) || "").trim(),
      token: String(params.get(AUTOFILL_PARAMS.token) || "").trim(),
      hasClient,
      hasToken
    };
  }
  function removeAutofillHashParams(rawUrl) {
    let url;
    try {
      url = new URL(String(rawUrl || ""));
    } catch {
      return null;
    }
    const rawHash = url.hash ? url.hash.slice(1) : "";
    if (!rawHash) {
      return null;
    }
    const params = new URLSearchParams(rawHash.startsWith("?") ? rawHash.slice(1) : rawHash);
    let changed = false;
    for (const key of [AUTOFILL_PARAMS.client, AUTOFILL_PARAMS.token]) {
      if (params.has(key)) {
        params.delete(key);
        changed = true;
      }
    }
    if (!changed) {
      return null;
    }
    const nextHash = params.toString();
    url.hash = nextHash ? nextHash : "";
    return url.toString();
  }

  // src/content/page/whatsapp-page.ts
  function pageText() {
    return String(document.body?.innerText || "").toLowerCase();
  }
  function hasQrCanvas() {
    return Array.from(document.querySelectorAll("canvas, [data-testid], [aria-label]")).some((element) => {
      const testId = String(element.getAttribute("data-testid") || "").toLowerCase();
      const aria = String(element.getAttribute("aria-label") || "").toLowerCase();
      return testId.includes("qr") || aria.includes("qr") || aria.includes("scan");
    });
  }
  function isQrLoginScreen() {
    const text = pageText();
    return hasQrCanvas() || WHATSAPP_QR_HINTS.some((hint) => text.includes(hint));
  }
  function isWhatsAppLoggedIn() {
    if (isQrLoginScreen()) {
      return false;
    }
    return WHATSAPP_LOGGED_IN_SELECTORS.some((selector) => {
      try {
        return Boolean(document.querySelector(selector));
      } catch {
        return false;
      }
    });
  }
  function isColorDark(value) {
    const raw = String(value || "").trim();
    let r;
    let g;
    let b;
    const rgb = raw.match(/^rgba?\(([^)]+)\)$/i);
    if (rgb) {
      const parts = rgb[1].split(",").map((part) => parseFloat(part));
      [r, g, b] = parts;
    } else {
      const hex = raw.replace(/^#/, "");
      if (hex.length === 3) {
        r = parseInt(hex[0] + hex[0], 16);
        g = parseInt(hex[1] + hex[1], 16);
        b = parseInt(hex[2] + hex[2], 16);
      } else if (hex.length >= 6) {
        r = parseInt(hex.slice(0, 2), 16);
        g = parseInt(hex.slice(2, 4), 16);
        b = parseInt(hex.slice(4, 6), 16);
      } else {
        return null;
      }
    }
    if (![r, g, b].every(Number.isFinite)) {
      return null;
    }
    const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    return luminance < 0.5;
  }
  function isWhatsAppDarkTheme() {
    const classes = `${document.body?.className || ""} ${document.documentElement?.className || ""}`.toLowerCase();
    if (/(^|[\s-])dark($|[\s-])/.test(classes)) {
      return true;
    }
    if (/(^|[\s-])light($|[\s-])/.test(classes)) {
      return false;
    }
    const source = document.documentElement || document.body;
    if (source) {
      const style = getComputedStyle(source);
      const surface = style.getPropertyValue("--WDS-surface-default") || style.getPropertyValue("--app-background") || (document.body ? getComputedStyle(document.body).backgroundColor : "");
      const dark = isColorDark(surface);
      if (dark != null) {
        return dark;
      }
    }
    return false;
  }
  function applyWhatsAppTheme(host) {
    if (host) {
      host.dataset.theme = isWhatsAppDarkTheme() ? "dark" : "light";
    }
  }
  function startWhatsAppThemeWatch(host, existingObserver, onThemeChange) {
    applyWhatsAppTheme(host);
    if (existingObserver || typeof MutationObserver !== "function") {
      return existingObserver;
    }
    const observer = new MutationObserver(onThemeChange);
    for (const target of [document.documentElement, document.body]) {
      if (target) {
        observer.observe(target, { attributes: true, attributeFilter: ["class"] });
      }
    }
    return observer;
  }

  // src/content/panel/icons.ts
  function iconEye() {
    return `
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
      <circle cx="12" cy="12" r="3" />
      <line class="eye-off" x1="4" y1="20" x2="20" y2="4" />
    </svg>
  `;
  }
  function iconClose() {
    return `
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  `;
  }
  function iconImport() {
    return `
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 4v10" />
      <path d="m8 10 4 4 4-4" />
      <path d="M6 18h12" />
    </svg>
  `;
  }
  function iconSettings() {
    return `
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z" />
      <path d="M19.4 15a1.8 1.8 0 0 0 .36 1.98l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.8 1.8 0 0 0-1.98-.36 1.8 1.8 0 0 0-1.1 1.65V21a2 2 0 1 1-4 0v-.09A1.8 1.8 0 0 0 8.8 19.3a1.8 1.8 0 0 0-1.98.36l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.8 1.8 0 0 0 4.35 15a1.8 1.8 0 0 0-1.65-1.1H2.6a2 2 0 1 1 0-4h.09A1.8 1.8 0 0 0 4.35 8a1.8 1.8 0 0 0-.36-1.98l-.06-.06A2 2 0 1 1 6.76 3.1l.06.06A1.8 1.8 0 0 0 8.8 3.5 1.8 1.8 0 0 0 9.9 1.85V1.8a2 2 0 1 1 4 0v.09A1.8 1.8 0 0 0 15 3.5a1.8 1.8 0 0 0 1.98-.36l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.8 1.8 0 0 0 19.45 8a1.8 1.8 0 0 0 1.65 1.1h.09a2 2 0 1 1 0 4h-.09A1.8 1.8 0 0 0 19.4 15Z" />
    </svg>
  `;
  }

  // src/content/panel/template.ts
  var PANEL_TEXT = EXTENSION_CUSTOMIZATION.panelText;
  var PANEL_HOST_ID = "session-connector-panel";
  function panelTemplate(version) {
    return `
    <style>
      :host {
        all: initial;
        color-scheme: light;
        /* WhatsApp Web (WDS) - tema claro (valores exatos dos tokens) */
        --connector-panel: #ffffff;
        --connector-topbar: #f7f5f3;
        --connector-input: #f0f2f5;
        --connector-text: #0a0a0a;
        --connector-muted: rgba(0, 0, 0, 0.6);
        --connector-line: rgba(0, 0, 0, 0.1);
        --connector-panel-border: rgba(0, 0, 0, 0.1);
        --connector-accent: #1daa61;
        --connector-accent-hover: #1b8755;
        --connector-accent-text: #ffffff;
        --connector-hover: rgba(194, 189, 184, 0.15);
        --connector-notice: #f7f5f3;
        --connector-focus: rgba(29, 170, 97, 0.3);
        --connector-danger: #ea0038;
        --connector-danger-soft: #fde8eb;
        --connector-ok: #1b8755;
        --connector-ok-soft: #e7fce3;
        --connector-warn: #a5691b;
        --connector-warn-soft: #fff7e5;
        --connector-warn-border: rgba(197, 135, 48, 0.35);
        --connector-shadow: 0 16px 44px rgba(11, 20, 26, 0.22), 0 0 22px rgba(29, 170, 97, 0.18);
        --connector-primary-shadow: rgba(29, 170, 97, 0.2);
        --connector-font: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
        display: block;
        font-family: var(--connector-font);
        pointer-events: auto;
        position: fixed;
        right: 20px;
        top: 20px;
        z-index: 2147483647;
      }

      :host([data-theme="dark"]) {
        color-scheme: dark;
        /* WhatsApp Web (WDS) - tema escuro (valores exatos dos tokens) */
        --connector-panel: #1d1f1f;
        --connector-topbar: #1d1f1f;
        --connector-input: #242626;
        --connector-text: #fafafa;
        --connector-muted: rgba(255, 255, 255, 0.6);
        --connector-line: rgba(255, 255, 255, 0.1);
        --connector-accent: #21c063;
        --connector-accent-hover: #1daa61;
        --connector-accent-text: #0a0a0a;
        --connector-hover: rgba(255, 255, 255, 0.1);
        --connector-notice: #161717;
        --connector-focus: rgba(33, 192, 99, 0.3);
        --connector-danger: #fb5061;
        --connector-danger-soft: #321622;
        --connector-ok: #71eb85;
        --connector-ok-soft: #103529;
        --connector-warn: #ffd279;
        --connector-warn-soft: #362c1f;
        --connector-warn-border: rgba(255, 210, 121, 0.32);
        --connector-panel-border: rgba(33, 192, 99, 0.28);
        --connector-shadow: 0 18px 46px rgba(0, 0, 0, 0.6), 0 0 30px rgba(33, 192, 99, 0.28);
        --connector-primary-shadow: rgba(33, 192, 99, 0.24);
      }

      * {
        box-sizing: border-box;
      }

      .panel,
      .panel button,
      .panel input {
        font-family: var(--connector-font);
      }

      [hidden] {
        display: none !important;
      }

      .panel {
        background: var(--connector-panel);
        border: 1px solid var(--connector-panel-border);
        border-radius: 8px;
        box-shadow: var(--connector-shadow);
        color: var(--connector-text);
        display: grid;
        max-height: calc(100vh - 32px);
        overflow: hidden;
        pointer-events: auto;
        width: min(368px, calc(100vw - 32px));
      }

      .topbar {
        align-items: center;
        background: var(--connector-topbar);
        border-bottom: 1px solid var(--connector-line);
        display: flex;
        gap: 12px;
        justify-content: space-between;
        min-height: 68px;
        padding: 14px 16px;
      }

      .brand {
        align-items: center;
        cursor: pointer;
        display: grid;
        gap: 10px;
        grid-template-columns: 36px minmax(0, 1fr);
        min-width: 0;
      }

      .mark {
        align-items: center;
        background: var(--connector-accent);
        border-radius: 8px;
        color: var(--connector-accent-text);
        display: flex;
        font-family: var(--connector-font);
        font-size: 18px;
        font-weight: 700;
        line-height: 1;
        height: 36px;
        justify-content: center;
        width: 36px;
      }

      .mark svg {
        fill: none;
        height: 21px;
        stroke: currentColor;
        stroke-linecap: round;
        stroke-linejoin: round;
        stroke-width: 2.2;
        width: 21px;
      }

      .title {
        color: var(--connector-text);
        display: block;
        font-size: 16px;
        font-weight: 700;
        letter-spacing: 0;
        line-height: 1.2;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .subtitle {
        color: var(--connector-muted);
        display: block;
        font-size: 12px;
        letter-spacing: 0;
        line-height: 1.3;
        margin-top: 2px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .icon-button {
        align-items: center;
        background: transparent;
        border: 0;
        border-radius: 6px;
        color: var(--connector-muted);
        cursor: pointer;
        display: inline-flex;
        flex: 0 0 auto;
        height: 34px;
        justify-content: center;
        margin: 0;
        padding: 0;
        width: 34px;
      }

      .header-actions {
        align-items: center;
        display: flex;
        gap: 4px;
      }

      .icon-button:hover,
      .icon-button:focus-visible {
        background: var(--connector-hover);
        color: var(--connector-text);
        outline: none;
      }

      .icon-button svg,
      .token-toggle svg {
        fill: none;
        height: 18px;
        stroke: currentColor;
        stroke-linecap: round;
        stroke-linejoin: round;
        stroke-width: 2;
        width: 18px;
      }

      form {
        display: grid;
        gap: 14px;
        max-height: calc(100vh - 180px);
        overflow-y: auto;
        padding: 16px 18px 18px;
      }

      label {
        color: var(--connector-text);
        display: grid;
        font-size: 12px;
        font-weight: 700;
        gap: 6px;
        letter-spacing: 0;
      }

      input {
        background: var(--connector-input);
        border: 1px solid transparent;
        border-radius: 8px;
        color: var(--connector-text);
        font-family: var(--connector-font);
        font-size: 14px;
        line-height: 1.45;
        height: 40px;
        letter-spacing: 0;
        outline: none;
        padding: 0 11px;
        transition: border-color 120ms ease, box-shadow 120ms ease, background 120ms ease;
        width: 100%;
      }

      input:focus {
        background: var(--connector-input);
        border-color: var(--connector-accent);
        box-shadow: 0 0 0 3px var(--connector-focus);
      }

      input:disabled {
        background: var(--connector-input);
        color: var(--connector-muted);
        cursor: not-allowed;
      }

      .token-field {
        display: block;
        position: relative;
      }

      .token-field input {
        padding-right: 44px;
      }

      .token-toggle {
        align-items: center;
        background: transparent;
        border: 0;
        border-radius: 4px;
        color: var(--connector-muted);
        cursor: pointer;
        display: inline-flex;
        height: 34px;
        justify-content: center;
        margin: 0;
        padding: 0;
        position: absolute;
        right: 3px;
        top: 3px;
        width: 38px;
      }

      .token-toggle:hover,
      .token-toggle:focus-visible {
        background: var(--connector-hover);
        box-shadow: 0 0 0 2px var(--connector-focus);
        color: var(--connector-text);
        outline: none;
      }

      .token-toggle .eye-off {
        display: none;
      }

      .token-toggle.is-visible .eye-off {
        display: block;
      }

      .check {
        align-items: center;
        cursor: pointer;
        display: grid;
        font-size: 13px;
        font-weight: 700;
        gap: 9px;
        grid-template-columns: 16px minmax(0, 1fr);
        line-height: 1.35;
        min-height: 20px;
      }

      .check input[type="checkbox"] {
        appearance: none;
        background: transparent;
        border: 1px solid var(--connector-muted);
        border-radius: 3px;
        cursor: pointer;
        display: grid;
        height: 16px;
        margin: 0;
        min-height: 16px;
        min-width: 16px;
        padding: 0;
        place-content: center;
        width: 16px;
      }

      .check input[type="checkbox"]::before {
        border-bottom: 2px solid var(--connector-accent-text);
        border-right: 2px solid var(--connector-accent-text);
        content: "";
        height: 8px;
        margin-bottom: 3px;
        transform: rotate(45deg) scale(0);
        width: 5px;
      }

      .check input[type="checkbox"]:checked {
        background: var(--connector-accent);
        border-color: var(--connector-accent);
      }

      .check input[type="checkbox"]:checked::before {
        transform: rotate(45deg) scale(1);
      }

      .check input[type="checkbox"]:focus-visible {
        box-shadow: 0 0 0 3px var(--connector-focus);
        outline: none;
      }

      .actions {
        display: grid;
        gap: 9px;
      }

      .primary,
      .secondary {
        align-items: center;
        background: var(--connector-accent);
        border: 0;
        border-radius: 6px;
        color: var(--connector-accent-text);
        cursor: pointer;
        display: inline-flex;
        font-family: var(--connector-font);
        font-size: 14px;
        font-weight: 700;
        line-height: 1;
        height: 42px;
        justify-content: center;
        letter-spacing: 0;
        margin: 0;
        padding: 0 14px;
        transition: background 120ms ease, box-shadow 120ms ease, transform 120ms ease;
        width: 100%;
      }

      .primary:hover,
      .primary:focus-visible {
        background: var(--connector-accent-hover);
        box-shadow: 0 8px 18px var(--connector-primary-shadow);
        outline: none;
      }

      .secondary {
        background: transparent;
        border: 1px solid var(--connector-line);
        color: var(--connector-text);
      }

      .secondary:hover,
      .secondary:focus-visible {
        background: var(--connector-hover);
        box-shadow: none;
        outline: none;
      }

      .primary:active,
      .secondary:active {
        transform: translateY(1px);
      }

      .primary:disabled,
      .secondary:disabled {
        background: var(--connector-input);
        color: var(--connector-muted);
        box-shadow: none;
        cursor: not-allowed;
        transform: none;
      }

      .notice {
        background: var(--connector-notice);
        border: 1px solid var(--connector-line);
        border-radius: 8px;
        color: var(--connector-muted);
        font-family: var(--connector-font);
        font-size: 12px;
        line-height: 1.45;
        letter-spacing: 0;
        margin: 0;
        padding: 9px 11px;
      }

      .notice strong {
        color: var(--connector-text);
      }

      .notice.warn {
        background: var(--connector-warn-soft);
        border-color: var(--connector-warn-border);
        color: var(--connector-warn);
      }

      .notice.warn strong {
        color: var(--connector-warn);
      }

      .settings-panel {
        border-top: 1px solid var(--connector-line);
        display: grid;
        gap: 12px;
        padding: 14px 18px 16px;
      }

      .settings-title {
        color: var(--connector-text);
        font-size: 13px;
        font-weight: 700;
        line-height: 1.25;
        margin: 0;
      }

      .settings-panel select {
        background: var(--connector-input);
        border: 1px solid transparent;
        border-radius: 8px;
        color: var(--connector-text);
        font-family: var(--connector-font);
        font-size: 14px;
        height: 38px;
        padding: 0 10px;
        width: 100%;
      }

      .setting-hint {
        color: var(--connector-muted);
        display: block;
        font-size: 11px;
        font-weight: 500;
        line-height: 1.35;
        margin-top: 2px;
      }

      .result {
        background: var(--connector-notice);
        border-top: 1px solid var(--connector-line);
        color: var(--connector-muted);
        font-family: var(--connector-font);
        font-size: 12px;
        line-height: 1.45;
        letter-spacing: 0;
        margin: 0;
        overflow-wrap: anywhere;
        padding: 12px 18px;
      }

      .result:empty {
        display: none;
      }

      .result.ok {
        background: var(--connector-ok-soft);
        color: var(--connector-ok);
      }

      .result.warn {
        background: var(--connector-warn-soft);
        color: var(--connector-warn);
      }

      .result.error {
        background: var(--connector-danger-soft);
        color: var(--connector-danger);
      }

      .meta {
        align-items: center;
        border-top: 1px solid var(--connector-line);
        color: var(--connector-muted);
        display: flex;
        font-family: var(--connector-font);
        font-size: 12px;
        line-height: 1.35;
        justify-content: space-between;
        letter-spacing: 0;
        min-height: 38px;
        padding: 9px 18px 10px;
      }

      @media (max-width: 480px) {
        :host {
          top: 12px;
          left: 12px;
          right: 12px;
        }

        .panel {
          width: auto;
        }
      }
    </style>

    <section class="panel" role="dialog" aria-label="${PANEL_TEXT.title}">
      <header class="topbar">
        <div id="devModeToggleArea" class="brand" title="Modo t\xE9cnico">
          <span class="mark" aria-hidden="true">${iconImport()}</span>
          <span>
            <span class="title">${PANEL_TEXT.title}</span>
            <span id="statusLabel" class="subtitle">${PANEL_TEXT.defaultStatus}</span>
          </span>
        </div>
        <div class="header-actions">
          <button id="settingsButton" class="icon-button" type="button" aria-label="${PANEL_TEXT.openSettings}" title="${PANEL_TEXT.openSettings}" aria-pressed="false">
            ${iconSettings()}
          </button>
          <button id="closeButton" class="icon-button" type="button" aria-label="${PANEL_TEXT.closePanel}" title="${PANEL_TEXT.closePanel}">
            ${iconClose()}
          </button>
        </div>
      </header>

      <form id="importForm">
        <label>
          ${PANEL_TEXT.clientLabel}
          <input id="serverUrlInput" type="text" autocomplete="off" spellcheck="false" placeholder="${PANEL_TEXT.clientPlaceholder}" />
        </label>
        <label>
          ${PANEL_TEXT.tokenLabel}
          <span class="token-field">
            <input id="instanceTokenInput" type="password" autocomplete="off" placeholder="${PANEL_TEXT.tokenPlaceholder}" />
            <button
              id="tokenVisibilityButton"
              class="token-toggle"
              type="button"
              aria-label="${PANEL_TEXT.showToken}"
              aria-pressed="false"
              title="${PANEL_TEXT.showToken}"
            >
              ${iconEye()}
            </button>
          </span>
        </label>
        <label id="includeHistoryOption" class="check">
          <input id="includeHistoryCheckbox" type="checkbox" checked />
          <span>${PANEL_TEXT.includeHistory}</span>
        </label>
        <label id="disconnectLocalOption" class="check dev-only" hidden>
          <input id="disconnectLocalCheckbox" type="checkbox" checked />
          <span>${PANEL_TEXT.disconnectLocal}</span>
        </label>
        <div class="actions">
          <button id="importButton" class="primary" type="submit">${PANEL_TEXT.importButton}</button>
          <button id="diagnoseButton" class="secondary dev-only" type="button" hidden>${PANEL_TEXT.diagnoseButton}</button>
          <button id="dumpButton" class="secondary dev-only" type="button" hidden>${PANEL_TEXT.dumpHistoryButton}</button>
          <button id="historyOnlyButton" class="secondary dev-only" type="button" hidden>${PANEL_TEXT.historyOnlyButton}</button>
          <button id="mainDumpButton" class="secondary dev-only" type="button" hidden>${PANEL_TEXT.dumpSessionButton}</button>
          <button id="exitDevModeButton" class="secondary dev-only" type="button" hidden>${PANEL_TEXT.exitDevModeButton}</button>
        </div>
        <p id="cleanupNotice" class="notice">${PANEL_TEXT.cleanupNoticeHTML}</p>
      </form>

      <section id="settingsPanel" class="settings-panel" aria-label="${PANEL_TEXT.settingsTitle}" hidden>
        <p class="settings-title">${PANEL_TEXT.settingsTitle}</p>
        <label id="autoOpenOption" class="check">
          <input id="autoOpenCheckbox" type="checkbox" />
          <span>
            ${PANEL_TEXT.autoOpenSetting}
            <span class="setting-hint">${PANEL_TEXT.autoOpenSettingHint}</span>
          </span>
        </label>
        <label>
          ${PANEL_TEXT.themeSetting}
          <select id="themeModeSelect">
            <option value="auto">${PANEL_TEXT.themeFollowWhatsApp}</option>
            <option value="light">${PANEL_TEXT.themeLight}</option>
            <option value="dark">${PANEL_TEXT.themeDark}</option>
          </select>
        </label>
        <label id="saveTokenOption" class="check">
          <input id="saveTokenCheckbox" type="checkbox" />
          <span>
            ${PANEL_TEXT.saveTokenSetting}
            <span class="setting-hint">${PANEL_TEXT.saveTokenSettingHint}</span>
          </span>
        </label>
      </section>

      <p id="result" class="result" aria-live="polite"></p>
      <footer class="meta">
        <span id="modeLabel">${PANEL_TEXT.modeDefault}</span>
        <span>Vers\xE3o <span id="extensionVersion">${version ? `v${version}` : "--"}</span></span>
      </footer>
    </section>
  `;
  }

  // src/content/index.ts
  (() => {
    const existingLoader = window.__sessionConnectorLoaded;
    const loaderRuntimeId = (() => {
      try {
        return chrome.runtime?.id || "";
      } catch {
        return "";
      }
    })();
    if (existingLoader && typeof existingLoader === "object" && existingLoader.active === true && existingLoader.runtimeId === loaderRuntimeId) {
      return;
    }
    window.__sessionConnectorLoaded = {
      active: true,
      runtimeId: loaderRuntimeId,
      loadedAt: Date.now()
    };
    const DEV_MODE_TOGGLE_CLICKS = 5;
    const DEV_MODE_TOGGLE_WINDOW_MS = 2500;
    const DEFAULT_USER_SETTINGS = {
      autoOpenPanel: true,
      themeMode: "auto",
      saveToken: true
    };
    const state = {
      host: null,
      root: null,
      importRunning: false,
      importPort: null,
      themeObserver: null,
      cleanupStarted: false,
      extensionContextInvalidated: false,
      devMode: false,
      settingsOpen: false,
      userSettings: { ...DEFAULT_USER_SETTINGS },
      pendingAutofillToken: "",
      devModeClickCount: 0,
      devModeClickTimer: null
    };
    function extensionContextError(error) {
      const message = String(error?.message || error || "");
      return message.includes("Extension context invalidated") || message.includes("context invalidated") || message.includes("Cannot read properties of undefined (reading 'local')") || message.includes("Cannot read properties of undefined (reading 'connect')") || message.includes("Cannot read properties of undefined (reading 'getManifest')");
    }
    function hasExtensionContext() {
      try {
        return typeof chrome !== "undefined" && Boolean(chrome.runtime?.id) && Boolean(chrome.storage?.local);
      } catch {
        return false;
      }
    }
    function markExtensionContextInvalidated() {
      const wasInvalidated = state.extensionContextInvalidated;
      state.extensionContextInvalidated = true;
      if (!wasInvalidated) {
        if (window.__sessionConnectorLoaded && typeof window.__sessionConnectorLoaded === "object") {
          window.__sessionConnectorLoaded.active = false;
        }
        closeImportPort();
        setBusy(false);
      }
      setResult(PANEL_TEXT.extensionInvalidated, "error");
    }
    function handleExtensionContextFailure(error) {
      if (!extensionContextError(error) && hasExtensionContext()) {
        return false;
      }
      markExtensionContextInvalidated();
      return true;
    }
    function warnIfActiveContext(label, error) {
      if (!handleExtensionContextFailure(error)) {
        console.warn(label, error);
      }
    }
    async function storageGet(keys, fallback = {}) {
      if (!hasExtensionContext()) {
        markExtensionContextInvalidated();
        return fallback;
      }
      try {
        return await chrome.storage.local.get(keys);
      } catch (error) {
        if (handleExtensionContextFailure(error)) {
          return fallback;
        }
        throw error;
      }
    }
    async function storageSet(values) {
      if (!hasExtensionContext()) {
        markExtensionContextInvalidated();
        return false;
      }
      try {
        await chrome.storage.local.set(values);
        return true;
      } catch (error) {
        if (handleExtensionContextFailure(error)) {
          return false;
        }
        throw error;
      }
    }
    function extensionVersion() {
      try {
        return chrome.runtime?.getManifest?.().version || "";
      } catch (error) {
        handleExtensionContextFailure(error);
        return "";
      }
    }
    function normalizeUserSettings(value) {
      const raw = value && typeof value === "object" ? value : {};
      const themeMode = ["auto", "light", "dark"].includes(String(raw.themeMode)) ? String(raw.themeMode) : DEFAULT_USER_SETTINGS.themeMode;
      return {
        autoOpenPanel: raw.autoOpenPanel !== false,
        themeMode,
        saveToken: raw.saveToken !== false
      };
    }
    function cleanAutofillHash() {
      const nextUrl = removeAutofillHashParams(location.href);
      if (nextUrl) {
        history.replaceState(history.state, document.title || "", nextUrl);
      }
    }
    async function applyAutofillFromUrl() {
      const autofill = parseAutofillHash(location.href);
      if (!autofill) {
        return false;
      }
      cleanAutofillHash();
      if (!autofill.client) {
        return false;
      }
      const values = await storageGet([STORAGE_KEYS.userSettings]);
      state.userSettings = normalizeUserSettings(values[STORAGE_KEYS.userSettings]);
      state.pendingAutofillToken = autofill.token || "";
      await storageSet({
        [STORAGE_KEYS.serverUrl]: autofill.client,
        [STORAGE_KEYS.instanceToken]: state.userSettings.saveToken ? autofill.token || "" : ""
      });
      return true;
    }
    function applyThemeClass() {
      if (!state.host) {
        return;
      }
      if (state.userSettings.themeMode === "light" || state.userSettings.themeMode === "dark") {
        state.host.dataset.theme = state.userSettings.themeMode;
        return;
      }
      applyWhatsAppTheme(state.host);
    }
    function startThemeWatch() {
      state.themeObserver = startWhatsAppThemeWatch(state.host, state.themeObserver, applyThemeClass);
    }
    function panelEl(id) {
      return state.root?.getElementById(id) || null;
    }
    function setResult(message, kind = "") {
      const result = panelEl("result");
      if (!result) {
        return;
      }
      result.textContent = message || "";
      result.className = kind ? `result ${kind}` : "result";
    }
    function setStatus(message) {
      const label = panelEl("statusLabel");
      if (label) {
        label.textContent = message || PANEL_TEXT.defaultStatus;
      }
    }
    function refreshLoginStatus() {
      const loggedIn = isWhatsAppLoggedIn();
      setStatus(loggedIn ? PANEL_TEXT.defaultStatus : PANEL_TEXT.loggedOutStatus);
      return loggedIn;
    }
    function setBusy(busy) {
      state.importRunning = Boolean(busy);
      for (const id of [
        "serverUrlInput",
        "instanceTokenInput",
        "includeHistoryCheckbox",
        "disconnectLocalCheckbox",
        "importButton",
        "diagnoseButton",
        "dumpButton",
        "historyOnlyButton",
        "mainDumpButton",
        "exitDevModeButton",
        "tokenVisibilityButton",
        "settingsButton",
        "autoOpenCheckbox",
        "themeModeSelect",
        "saveTokenCheckbox"
      ]) {
        const element = panelEl(id);
        if (element) {
          const devOnly = element.classList.contains("dev-only") || Boolean(element.closest?.(".dev-only"));
          element.disabled = state.importRunning || devOnly && !state.devMode;
        }
      }
    }
    function renderExtensionVersion() {
      const versionEl = panelEl("extensionVersion");
      const version = extensionVersion();
      if (versionEl) {
        versionEl.textContent = version ? `v${version}` : "--";
      }
    }
    function shouldDisconnectLocalAfterImport() {
      const checkbox = panelEl("disconnectLocalCheckbox");
      return !state.devMode || checkbox?.checked !== false;
    }
    function shouldIncludeHistoryAfterImport() {
      const checkbox = panelEl("includeHistoryCheckbox");
      return checkbox ? checkbox.checked === true : DEFAULT_INCLUDE_HISTORY;
    }
    function renderCleanupNotice() {
      const notice = panelEl("cleanupNotice");
      if (!notice) {
        return;
      }
      if (shouldDisconnectLocalAfterImport()) {
        notice.className = "notice";
        notice.innerHTML = PANEL_TEXT.cleanupNoticeHTML;
        return;
      }
      notice.className = "notice warn";
      notice.innerHTML = PANEL_TEXT.keepLocalSessionWarningHTML;
    }
    function renderSettingsPanel() {
      const settingsPanel = panelEl("settingsPanel");
      const settingsButton = panelEl("settingsButton");
      const autoOpenCheckbox = panelEl("autoOpenCheckbox");
      const themeModeSelect = panelEl("themeModeSelect");
      const saveTokenCheckbox = panelEl("saveTokenCheckbox");
      if (settingsPanel) {
        settingsPanel.hidden = !state.settingsOpen;
      }
      if (settingsButton) {
        settingsButton.setAttribute("aria-pressed", state.settingsOpen ? "true" : "false");
        settingsButton.setAttribute("aria-label", state.settingsOpen ? PANEL_TEXT.closeSettings : PANEL_TEXT.openSettings);
        settingsButton.title = state.settingsOpen ? PANEL_TEXT.closeSettings : PANEL_TEXT.openSettings;
      }
      if (autoOpenCheckbox) {
        autoOpenCheckbox.checked = state.userSettings.autoOpenPanel;
      }
      if (themeModeSelect) {
        themeModeSelect.value = state.userSettings.themeMode;
      }
      if (saveTokenCheckbox) {
        saveTokenCheckbox.checked = state.userSettings.saveToken;
      }
    }
    async function saveUserSettings(next = {}) {
      state.userSettings = normalizeUserSettings({ ...state.userSettings, ...next });
      await storageSet({ [STORAGE_KEYS.userSettings]: state.userSettings });
      renderSettingsPanel();
      applyThemeClass();
    }
    function setDevMode(enabled) {
      state.devMode = Boolean(enabled);
      for (const element of Array.from(state.root?.querySelectorAll(".dev-only") || [])) {
        element.hidden = !state.devMode;
        element.disabled = state.importRunning || !state.devMode;
      }
      const disconnectLocalCheckbox = panelEl("disconnectLocalCheckbox");
      if (!state.devMode && disconnectLocalCheckbox) {
        disconnectLocalCheckbox.checked = true;
      }
      const modeLabel = panelEl("modeLabel");
      if (modeLabel) {
        modeLabel.textContent = state.devMode ? PANEL_TEXT.modeTechnical : PANEL_TEXT.modeDefault;
      }
      renderCleanupNotice();
      setBusy(state.importRunning);
    }
    async function setDevModePreference(enabled) {
      setDevMode(enabled);
      await storageSet({ [STORAGE_KEYS.devMode]: state.devMode });
      setResult(state.devMode ? `${PANEL_TEXT.modeTechnical} ativado.` : `${PANEL_TEXT.modeTechnical} desativado.`, "ok");
    }
    function handleDevModeGesture() {
      state.devModeClickCount += 1;
      if (state.devModeClickTimer) {
        clearTimeout(state.devModeClickTimer);
      }
      if (state.devModeClickCount >= DEV_MODE_TOGGLE_CLICKS) {
        state.devModeClickCount = 0;
        state.devModeClickTimer = null;
        setDevModePreference(!state.devMode).catch((error) => {
          warnIfActiveContext("Failed to toggle technical mode", error);
        });
        return;
      }
      state.devModeClickTimer = setTimeout(() => {
        state.devModeClickCount = 0;
        state.devModeClickTimer = null;
      }, DEV_MODE_TOGGLE_WINDOW_MS);
    }
    function setTokenVisible(visible) {
      const input = panelEl("instanceTokenInput");
      const button = panelEl("tokenVisibilityButton");
      if (!input || !button) {
        return;
      }
      input.type = visible ? "text" : "password";
      button.classList.toggle("is-visible", visible);
      button.setAttribute("aria-pressed", visible ? "true" : "false");
      button.setAttribute("aria-label", visible ? PANEL_TEXT.hideToken : PANEL_TEXT.showToken);
      button.title = visible ? PANEL_TEXT.hideToken : PANEL_TEXT.showToken;
    }
    async function loadSettings() {
      const values = await storageGet([
        STORAGE_KEYS.serverUrl,
        STORAGE_KEYS.instanceToken,
        STORAGE_KEYS.includeHistory,
        STORAGE_KEYS.disconnectLocal,
        STORAGE_KEYS.devMode,
        STORAGE_KEYS.userSettings
      ]);
      state.userSettings = normalizeUserSettings(values[STORAGE_KEYS.userSettings]);
      const serverUrlInput = panelEl("serverUrlInput");
      const instanceTokenInput = panelEl("instanceTokenInput");
      const includeHistoryCheckbox = panelEl("includeHistoryCheckbox");
      const disconnectLocalCheckbox = panelEl("disconnectLocalCheckbox");
      if (serverUrlInput) {
        serverUrlInput.value = values[STORAGE_KEYS.serverUrl] || "";
      }
      if (instanceTokenInput) {
        instanceTokenInput.value = state.pendingAutofillToken || (state.userSettings.saveToken ? values[STORAGE_KEYS.instanceToken] || "" : "");
      }
      if (includeHistoryCheckbox) {
        includeHistoryCheckbox.checked = values[STORAGE_KEYS.includeHistory] === void 0 ? DEFAULT_INCLUDE_HISTORY : values[STORAGE_KEYS.includeHistory] === true;
      }
      if (disconnectLocalCheckbox) {
        disconnectLocalCheckbox.checked = values[STORAGE_KEYS.devMode] === true ? values[STORAGE_KEYS.disconnectLocal] !== false : true;
      }
      setDevMode(values[STORAGE_KEYS.devMode] === true);
      renderSettingsPanel();
      applyThemeClass();
    }
    async function saveSettings() {
      const serverUrlInput = panelEl("serverUrlInput");
      const instanceTokenInput = panelEl("instanceTokenInput");
      const includeHistoryCheckbox = panelEl("includeHistoryCheckbox");
      const disconnectLocalCheckbox = panelEl("disconnectLocalCheckbox");
      await storageSet({
        [STORAGE_KEYS.serverUrl]: String(serverUrlInput?.value || "").trim(),
        [STORAGE_KEYS.instanceToken]: state.userSettings.saveToken ? String(instanceTokenInput?.value || "").trim() : "",
        [STORAGE_KEYS.includeHistory]: shouldIncludeHistoryAfterImport(),
        [STORAGE_KEYS.disconnectLocal]: state.devMode ? disconnectLocalCheckbox?.checked !== false : true
      });
      renderCleanupNotice();
    }
    function closeImportPort() {
      if (!state.importPort) {
        return;
      }
      try {
        state.importPort.disconnect();
      } catch {
      }
      state.importPort = null;
    }
    function downloadJSON(filename, data) {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename;
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    }
    function handlePortMessage(message, fallbackMessage) {
      if (!message) {
        return;
      }
      if (message.type === PORT_MESSAGE_TYPES.status) {
        if (String(message.message || "").includes("Desconectando WhatsApp Web local")) {
          state.cleanupStarted = true;
        }
        setResult(message.message || "", message.kind || "");
        return;
      }
      if (message.type === PORT_MESSAGE_TYPES.done) {
        const download = message.payload?.download;
        if (download?.filename && download.data !== void 0) {
          downloadJSON(download.filename, download.data);
        }
        setResult(message.message || fallbackMessage, message.kind || "ok");
        setBusy(false);
        closeImportPort();
        return;
      }
      if (message.type === PORT_MESSAGE_TYPES.error) {
        setResult(message.message || "Falha ao executar comando.", "error");
        setBusy(false);
        closeImportPort();
      }
    }
    function runBackgroundCommand(type, options = {}, fallbackMessage = "Comando conclu\xEDdo.") {
      if (state.importRunning) {
        return;
      }
      if (!hasExtensionContext()) {
        markExtensionContextInvalidated();
        return;
      }
      closeImportPort();
      state.cleanupStarted = false;
      setBusy(true);
      let port;
      try {
        port = chrome.runtime.connect({ name: PORT_NAMES.sessionImport });
      } catch (error) {
        if (handleExtensionContextFailure(error)) {
          return;
        }
        throw error;
      }
      state.importPort = port;
      port.onMessage.addListener((message) => handlePortMessage(message, fallbackMessage));
      port.onDisconnect.addListener(() => {
        state.importPort = null;
        if (state.importRunning && !state.cleanupStarted) {
          setResult("A conex\xE3o com a extens\xE3o foi encerrada.", "error");
          setBusy(false);
        }
      });
      port.postMessage({ type, options });
    }
    async function startImport(event) {
      event.preventDefault();
      if (state.importRunning) {
        return;
      }
      const client = String(panelEl("serverUrlInput")?.value || "").trim();
      const token = String(panelEl("instanceTokenInput")?.value || "").trim();
      const includeHistory = shouldIncludeHistoryAfterImport();
      const disconnectLocal = shouldDisconnectLocalAfterImport();
      if (!refreshLoginStatus()) {
        setResult("Entre no WhatsApp Web antes de migrar a sess\xE3o.", "error");
        return;
      }
      if (!client || !token) {
        setResult("Informe cliente e token da inst\xE2ncia.", "error");
        return;
      }
      setResult("Preparando importa\xE7\xE3o...");
      await saveSettings();
      runBackgroundCommand(BACKGROUND_COMMANDS.startImport, { client, token, includeHistory, disconnectLocal }, "Importa\xE7\xE3o conclu\xEDda.");
    }
    async function startHistoryOnlyImport() {
      if (state.importRunning) {
        return;
      }
      const client = String(panelEl("serverUrlInput")?.value || "").trim();
      const token = String(panelEl("instanceTokenInput")?.value || "").trim();
      if (!refreshLoginStatus()) {
        setResult("Entre no WhatsApp Web antes de repassar o hist\xF3rico.", "error");
        return;
      }
      if (!client || !token) {
        setResult("Informe cliente e token da inst\xE2ncia.", "error");
        return;
      }
      setResult("Preparando repasse de hist\xF3rico...");
      await saveSettings();
      runBackgroundCommand(BACKGROUND_COMMANDS.importHistoryOnly, { client, token }, "Hist\xF3rico repassado.");
    }
    function bindPanelEvents() {
      panelEl("closeButton")?.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (state.host) {
          state.host.style.display = "none";
        }
      });
      panelEl("devModeToggleArea")?.addEventListener("click", handleDevModeGesture);
      panelEl("settingsButton")?.addEventListener("click", () => {
        state.settingsOpen = !state.settingsOpen;
        renderSettingsPanel();
      });
      panelEl("autoOpenCheckbox")?.addEventListener("change", () => {
        saveUserSettings({ autoOpenPanel: panelEl("autoOpenCheckbox")?.checked !== false }).catch((error) => {
          warnIfActiveContext("Failed to save auto-open option", error);
        });
      });
      panelEl("themeModeSelect")?.addEventListener("change", () => {
        saveUserSettings({ themeMode: panelEl("themeModeSelect")?.value || "auto" }).catch((error) => {
          warnIfActiveContext("Failed to save theme option", error);
        });
      });
      panelEl("saveTokenCheckbox")?.addEventListener("change", () => {
        saveUserSettings({ saveToken: panelEl("saveTokenCheckbox")?.checked !== false }).then(() => saveSettings()).catch((error) => {
          warnIfActiveContext("Failed to save token storage option", error);
        });
      });
      panelEl("importForm")?.addEventListener("submit", startImport);
      panelEl("serverUrlInput")?.addEventListener("blur", () => {
        saveSettings().catch((error) => warnIfActiveContext("Failed to save client", error));
      });
      panelEl("instanceTokenInput")?.addEventListener("blur", () => {
        saveSettings().catch((error) => warnIfActiveContext("Failed to save token", error));
      });
      panelEl("includeHistoryCheckbox")?.addEventListener("change", () => {
        saveSettings().catch((error) => warnIfActiveContext("Failed to save history option", error));
      });
      panelEl("disconnectLocalCheckbox")?.addEventListener("change", () => {
        saveSettings().catch((error) => warnIfActiveContext("Failed to save local cleanup option", error));
      });
      panelEl("tokenVisibilityButton")?.addEventListener("click", () => {
        const input = panelEl("instanceTokenInput");
        setTokenVisible(input?.type === "password");
        input?.focus();
      });
      panelEl("diagnoseButton")?.addEventListener("click", () => {
        runBackgroundCommand(BACKGROUND_COMMANDS.diagnose, {}, "Diagn\xF3stico gerado.");
      });
      panelEl("dumpButton")?.addEventListener("click", () => {
        runBackgroundCommand(BACKGROUND_COMMANDS.dumpHistory, {}, "Hist\xF3rico gerado.");
      });
      panelEl("historyOnlyButton")?.addEventListener("click", () => {
        startHistoryOnlyImport().catch((error) => {
          setResult(error.message || "Falha ao repassar hist\xF3rico.", "error");
          setBusy(false);
        });
      });
      panelEl("mainDumpButton")?.addEventListener("click", () => {
        runBackgroundCommand(BACKGROUND_COMMANDS.dumpSession, {}, "Sess\xE3o gerada.");
      });
      panelEl("exitDevModeButton")?.addEventListener("click", () => {
        setDevModePreference(false).catch((error) => {
          warnIfActiveContext("Failed to disable technical mode", error);
        });
      });
    }
    async function ensurePanel() {
      if (state.host && state.root) {
        return;
      }
      const host = document.getElementById(PANEL_HOST_ID) || document.createElement("div");
      host.id = PANEL_HOST_ID;
      if (!host.isConnected) {
        (document.body || document.documentElement).append(host);
      }
      const root = host.shadowRoot || host.attachShadow({ mode: "open" });
      root.innerHTML = panelTemplate(extensionVersion());
      state.host = host;
      state.root = root;
      startThemeWatch();
      bindPanelEvents();
      renderExtensionVersion();
      await loadSettings();
      await saveUserSettings(state.userSettings);
      setTokenVisible(false);
    }
    async function openPanel() {
      await ensurePanel();
      if (!state.importRunning) {
        await loadSettings();
      }
      state.host.style.display = "";
      refreshLoginStatus();
      return true;
    }
    if (hasExtensionContext()) {
      try {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
          if (!message || message.type !== CONTENT_MESSAGE_TYPES.openPanel) {
            return false;
          }
          openPanel().then((opened) => sendResponse({ ok: opened, loggedIn: isWhatsAppLoggedIn() })).catch((error) => sendResponse({ ok: false, error: error.message || "Falha ao abrir painel" }));
          return true;
        });
      } catch (error) {
        handleExtensionContextFailure(error);
      }
    }
    window.addEventListener("hashchange", () => {
      applyAutofillFromUrl().then((changed) => {
        if (changed) {
          return openPanel();
        }
        return false;
      }).catch((error) => warnIfActiveContext("Failed to apply URL autofill", error));
    });
    applyAutofillFromUrl().then(async (changed) => {
      if (changed) {
        return openPanel();
      }
      const values = await storageGet([STORAGE_KEYS.userSettings]);
      const userSettings = normalizeUserSettings(values[STORAGE_KEYS.userSettings]);
      state.userSettings = userSettings;
      if (userSettings.autoOpenPanel) {
        return openPanel();
      }
      return false;
    }).catch((error) => warnIfActiveContext("Failed to open session connector panel", error));
  })();
})();
