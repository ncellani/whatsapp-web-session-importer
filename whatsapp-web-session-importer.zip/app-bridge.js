(() => {
  // src/customization.ts
  var EXTENSION_CUSTOMIZATION = {
    whatsappWebOrigin: "https://web.whatsapp.com",
    api: {
      clientBaseDomain: "uazapi.com",
      authHeaderName: "token",
      paths: {
        instanceStatus: "/instance/status",
        importWebSessionStart: "/instance/import-web-session/start",
        importWebSessionChunk: "/instance/import-web-session/chunk",
        importWebSessionFinish: "/instance/import-web-session/finish",
        importWebSessionHistory: "/instance/import-web-session/history"
      }
    },
    importLimits: {
      chunkItems: 1e3,
      historyChatLimit: 5e3
    },
    importDefaults: {
      // History is useful for continuity, but it depends on WhatsApp Web cache.
      // The service worker imports the session first and treats history failures
      // as warnings so this default cannot break the credential migration.
      includeHistory: false
    },
    appBridge: {
      source: "whatsapp-session-transfer",
      matches: [
        "https://connect.sessiontransfer.com/*",
        "https://*.uazapi.com/*"
      ]
    },
    panelText: {
      title: "Migrar sess\xE3o",
      defaultStatus: "WhatsApp Web conectado",
      loggedOutStatus: "Entre no WhatsApp Web para importar",
      clientLabel: "Cliente",
      clientPlaceholder: "ex: metrifiquei",
      tokenLabel: "Token",
      tokenPlaceholder: "token",
      importButton: "Migrar sess\xE3o",
      diagnoseButton: "Baixar diagn\xF3stico",
      dumpHistoryButton: "Baixar hist\xF3rico",
      historyOnlyButton: "Repassar hist\xF3rico",
      dumpSessionButton: "Baixar sess\xE3o",
      exitDevModeButton: "Sair do modo t\xE9cnico",
      modeDefault: "Modo padr\xE3o",
      modeTechnical: "Modo t\xE9cnico",
      showToken: "Mostrar token",
      hideToken: "Ocultar token",
      clearToken: "Apagar token",
      closePanel: "Fechar painel",
      openSettings: "Configura\xE7\xF5es",
      closeSettings: "Fechar configura\xE7\xF5es",
      settingsTitle: "Configura\xE7\xF5es",
      autoOpenSetting: "Abrir painel automaticamente",
      autoOpenSettingHint: "Mesmo desativado, chamadas pelo SDK/bridge continuam abrindo o painel.",
      themeSetting: "Tema do painel",
      themeFollowWhatsApp: "Seguir WhatsApp",
      themeLight: "Claro",
      themeDark: "Escuro",
      includeHistory: "Incluir hist\xF3rico de mensagens (beta)",
      disconnectLocal: "Apagar a sess\xE3o local ap\xF3s importar",
      cleanupNoticeHTML: "<strong>Aten\xE7\xE3o:</strong> esta sess\xE3o ser\xE1 migrada para o cliente informado e desconectada deste navegador.",
      keepLocalSessionWarningHTML: "<strong>Risco:</strong> manter a sess\xE3o neste navegador e na inst\xE2ncia ao mesmo tempo roda a mesma conta em dois lugares, o que pode causar desconex\xF5es, perda de mensagens e outros bugs. Use apenas para depura\xE7\xE3o.",
      extensionInvalidated: "A extens\xE3o foi atualizada ou recarregada. Recarregue esta aba do WhatsApp Web e tente novamente."
    }
  };

  // src/shared/config.ts
  var CLIENT_BASE_DOMAIN = EXTENSION_CUSTOMIZATION.api.clientBaseDomain;
  var WHATSAPP_WEB_ORIGIN = EXTENSION_CUSTOMIZATION.whatsappWebOrigin;
  var WHATSAPP_WEB_URL_PREFIX = `${WHATSAPP_WEB_ORIGIN}/`;
  var IMPORT_CHUNK_ITEMS = EXTENSION_CUSTOMIZATION.importLimits.chunkItems;
  var IMPORT_HISTORY_CHAT_LIMIT = EXTENSION_CUSTOMIZATION.importLimits.historyChatLimit;
  var DEFAULT_INCLUDE_HISTORY = EXTENSION_CUSTOMIZATION.importDefaults.includeHistory;
  var API_AUTH_HEADER_NAME = EXTENSION_CUSTOMIZATION.api.authHeaderName;
  var APP_BRIDGE_SOURCE = EXTENSION_CUSTOMIZATION.appBridge.source;
  var APP_BRIDGE_MATCHES = [...EXTENSION_CUSTOMIZATION.appBridge.matches];
  var APP_BRIDGE_MESSAGE_TYPES = {
    ready: "CONNECTOR_READY",
    ping: "PING",
    startImport: "START_IMPORT",
    openWhatsApp: "OPEN_WHATSAPP",
    started: "IMPORT_TAB_OPENED",
    error: "IMPORT_TAB_ERROR"
  };
  var API_PATHS = {
    instanceStatus: EXTENSION_CUSTOMIZATION.api.paths.instanceStatus,
    importWebSessionStart: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionStart,
    importWebSessionChunk: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionChunk,
    importWebSessionFinish: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionFinish,
    importWebSessionHistory: EXTENSION_CUSTOMIZATION.api.paths.importWebSessionHistory
  };

  // src/content/app-bridge.ts
  var guard = window;
  if (!guard.__whatsAppSessionTransferBridge) {
    guard.__whatsAppSessionTransferBridge = true;
    const buildResponse = (data, payload) => ({
      source: APP_BRIDGE_SOURCE,
      requestId: data?.requestId || "",
      ...payload
    });
    const postTo = (target, origin, payload) => {
      const receiver = target;
      if (!receiver || typeof receiver.postMessage !== "function") {
        return;
      }
      receiver.postMessage(payload, origin || "*");
    };
    const runtimeVersion = () => {
      try {
        return chrome.runtime?.getManifest?.().version || "";
      } catch {
        return null;
      }
    };
    const sendRuntimeMessage = (payload) => {
      try {
        if (!chrome.runtime?.sendMessage) {
          return Promise.reject(new Error("Extension context unavailable"));
        }
        return chrome.runtime.sendMessage(payload);
      } catch (error) {
        return Promise.reject(error);
      }
    };
    const announce = (target = window, origin = "*", data, versionOverride) => {
      const version = versionOverride === void 0 ? runtimeVersion() : versionOverride;
      if (version === null) {
        return;
      }
      postTo(target, origin, buildResponse(data, {
        source: APP_BRIDGE_SOURCE,
        type: APP_BRIDGE_MESSAGE_TYPES.ready,
        version
      }));
    };
    const announceEverywhere = () => {
      announce(window, "*");
      if (window.parent && window.parent !== window) {
        announce(window.parent, "*");
      }
    };
    const isSupportedSource = (event) => {
      if (event.source === window) {
        return true;
      }
      return Boolean(window.parent && window.parent !== window && event.source === window.parent);
    };
    window.addEventListener("message", (event) => {
      if (!isSupportedSource(event)) {
        return;
      }
      const data = event.data;
      if (!data || data.target !== APP_BRIDGE_SOURCE) {
        return;
      }
      if (data.type === APP_BRIDGE_MESSAGE_TYPES.ping) {
        void sendRuntimeMessage({ type: APP_BRIDGE_MESSAGE_TYPES.ping }).then((response) => {
          if (response?.ok) {
            announce(event.source, event.origin || "*", data, response.version || "");
          }
        }).catch(() => {
        });
        return;
      }
      if (data.type === APP_BRIDGE_MESSAGE_TYPES.startImport || data.type === APP_BRIDGE_MESSAGE_TYPES.openWhatsApp) {
        void sendRuntimeMessage({
          type: APP_BRIDGE_MESSAGE_TYPES.startImport,
          client: data.client || "",
          token: data.token || "",
          includeHistory: data.includeHistory,
          hideHistoryOption: data.hideHistoryOption,
          lockHistoryOption: data.lockHistoryOption,
          hideClientField: data.hideClientField,
          hideTokenField: data.hideTokenField,
          lockClientField: data.lockClientField,
          lockTokenField: data.lockTokenField,
          panelLayout: data.panelLayout
        }).then((response) => {
          postTo(event.source, event.origin || "*", buildResponse(data, {
            type: response?.ok ? APP_BRIDGE_MESSAGE_TYPES.started : APP_BRIDGE_MESSAGE_TYPES.error,
            error: response?.error || "",
            tabId: response?.tabId || null,
            reused: response?.reused === true
          }));
        }).catch((error) => {
          postTo(event.source, event.origin || "*", buildResponse(data, {
            type: APP_BRIDGE_MESSAGE_TYPES.error,
            error: error?.message || "Falha ao abrir WhatsApp Web"
          }));
        });
      }
    });
    announceEverywhere();
  }
})();
